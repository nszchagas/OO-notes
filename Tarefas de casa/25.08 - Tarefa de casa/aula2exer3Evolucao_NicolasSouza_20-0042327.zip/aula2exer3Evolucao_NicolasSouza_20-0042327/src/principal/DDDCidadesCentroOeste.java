package principal;

import java.util.Scanner;
/*
* Sintese: 
* Objetivo: Identifica o nome de uma capital do Centro-Oeste pelo DDD
* Entrada: DDD 
* Saida: DDD digitado e cidade a qual ele pertence 
*/

public class DDDCidadesCentroOeste {
	public static void main(String[] Args) {
		// Declaracoes 
		int ddd;
		Scanner scan = new Scanner(System.in);
		// Instrucoes
		 do {
			System.out.println(
					"Digite o DDD de uma das capitais do Centro-Oeste para saber o nome da cidade a qual ele pertence:");
			ddd = scan.nextInt();
			if (ddd <= 10 || ddd >= 100)
				System.out.println("O numero digitado nao e um DDD valido, insira um valor valido.");
		} while (ddd <= 10 || ddd >= 100);

		pulaLinhas(30);

		if (ddd > 10 && ddd < 100) 
		{
			switch (ddd) {
			case 61:
				System.out.print("O DDD digitado foi: " + ddd + ", e ele pertence a cidade: Bras�lia - DF");
				break;

			case 62:
				System.out.print("O DDD digitado foi: " + ddd + ", e ele pertence a cidade: Goi�nia - GO.");
				break;

			case 65:
				System.out.print("O DDD digitado foi: " + ddd + ", e ele pertence a cidade: Cuiab� - MT .");
				break;

			case 67:
				System.out.print("O DDD digitado foi: " + ddd + ", e ele pertence a cidade: Campo Grande - MS.");
				break;

			default:
				System.out.print("O DDD digitado (" + ddd + ") nao pertence a nenhuma capital do Centro-Oeste brasileiro.");
			}
		}

	}

	public static void pulaLinhas(int linhas) {
		for (int aux = 0; aux < linhas; aux++)
			System.out.println("\n");
	}

}
