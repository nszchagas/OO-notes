package principal;
import java.util.Scanner;

/*
* S�ntese: 
* Objetivo: retornar o sexo de um usu�rio baseado em uma primeira letra (M ou F)
* Entrada: primeira letra do sexo (M ou F)
* Sa�da: nome por extenso do sexo digitado (Masculino ou Feminino)
*/

public class SexoPorExtenso {
	public static void main(String[] args) {
		// Declaracoes
		String sexo;
		Scanner ler = new Scanner(System.in);
		
		// Instrucoes
		do {
			System.out.print("Digite o seu sexo? (M ou F)\n");
			sexo = ler.nextLine();
			if (sexo.equalsIgnoreCase("M") == false & sexo.equalsIgnoreCase("F") == false)
				System.out.println("O sexo inserido nao e valido. Insira M ou F.");

		} while (sexo.equalsIgnoreCase("M") == false & sexo.equalsIgnoreCase("F") == false);

		for (int aux = 0; aux < 3; aux++)
			System.out.print("\n");
		System.out.println("\t\t\t\t" + (sexo.equalsIgnoreCase("M") ? "MASCULINO" : "FEMININO"));
	}

}
