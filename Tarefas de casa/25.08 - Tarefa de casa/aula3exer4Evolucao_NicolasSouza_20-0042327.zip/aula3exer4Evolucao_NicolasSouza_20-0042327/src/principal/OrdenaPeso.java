package principal;

import java.text.DecimalFormat;
import java.util.Scanner;

/*
* Sintese: 
* Objetivo: Organiza o peso de elefantes em ordem crescente
* Entrada: Peso de tres elefantes
* Saida: Os pesos digitados, em ordem crescente 
*/

public class OrdenaPeso {

	public static void main(String[] args) {
		// DECLARACOES
		final int MAX = 3, PESOMINIMO = 5;

		DecimalFormat mascara = new DecimalFormat("#0.00");
		float[] peso = new float[MAX];
		Scanner ler = new Scanner(System.in);

		// INSTRUCOES

		for (int contador = 0; contador < MAX; contador++) {
			do {
				System.out.println("Digite o peso do " + (contador + 1) + "� elefante:");
				peso[contador] = ler.nextFloat();
				
				if (validaPeso(peso[contador], PESOMINIMO)== false) {
					System.out.println("Peso Invalido! Informe peso maior que " + PESOMINIMO + ".");
				}
				else 
					break;

			} while (validaPeso(peso[contador], PESOMINIMO) == false);
		}
	
			
		ordenaVetor(peso);
		limpaTela();
		
		System.out.println("Pesos Gravados \n\n");

		for (int aux = 0; aux < MAX; aux++) {
			System.out.println("Peso [" + (aux + 1) + "] = " + mascara.format(peso[aux]));
		}

	}
	
	
	public static void ordenaVetor(float[] vetor)
	{
		 float pivo;
		 
		 for (int contador = 1 ; contador < vetor.length ; contador++)
		 {
			 pivo = vetor[contador]; // guarda a posi��o "contador" em outra vari�vel
			 int aux = contador-1; // cria outro contador, � esquerda da posi��o contador
			 
			 while (aux >= 0 && vetor[aux]>pivo)
			 { 
				 vetor[aux+1] = vetor[aux]; // se o n�mero da posi��o aux for maior que o pivo, manda esse n�mero para a direita
				 aux -= 1; // aux = contador
			 }
			 
			 vetor[aux+1] = pivo; // devolve o pivo para o vetor
			 			 
		 }
		 		
	}
	
	
	public static void limpaTela() {
		for (int aux = 0; aux < 30; aux++)
			System.out.println("\n");
	}

	public static boolean validaPeso(float peso, float PESOMINIMO) {
		
		if (peso >= PESOMINIMO)
			return true;
		else 
			return false;

		}
}
