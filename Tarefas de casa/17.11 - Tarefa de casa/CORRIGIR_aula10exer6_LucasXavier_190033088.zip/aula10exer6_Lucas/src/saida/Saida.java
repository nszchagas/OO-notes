package saida;

import javax.swing.JOptionPane;

public class Saida {
	public static void limpaTela(int n) {
		for (int i = 0; i < n; i++)
			System.out.println();
	}
	
	public static void mostraMensagemConsole(String msg) {
		limpaTela(30);
		System.out.println(msg);
	}
	
	public static String solicitaDado(String msg, String titulo) {
		return JOptionPane.showInputDialog(null, msg, titulo, JOptionPane.PLAIN_MESSAGE);
	}
	
	public static void mostraMensagem(String msg, String titulo) {
		JOptionPane.showMessageDialog(null, msg, titulo, JOptionPane.INFORMATION_MESSAGE);
	}
	
	public static void mostraErro(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Erro", JOptionPane.ERROR_MESSAGE);
	}
	
	public static int perguntaContinua() {
		return JOptionPane.showConfirmDialog(null, "Deseja cadastrar outro time?", "Cadastro de Time", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	}
	
	public static int perguntaOutroTitulo() {
		return JOptionPane.showConfirmDialog(null, "Deseja cadastrar mais um titulo?", "Cadastro de Time", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
	}
}
