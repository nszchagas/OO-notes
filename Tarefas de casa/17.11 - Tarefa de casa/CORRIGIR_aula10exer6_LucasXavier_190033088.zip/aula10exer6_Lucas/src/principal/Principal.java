package principal;

import dados.TimeDeFutebol;
import saida.Saida;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {
		TimeDeFutebol time = null;
		int qtdTimes = 0;
		
		do {
			try {
				time = new TimeDeFutebol(Validacao.validaNome());
				qtdTimes++;
				
				while (Validacao.validaOutroTitulo()) {
					time.addAno(Validacao.validaAno());
				}
				
			}
			catch (NullPointerException ex) {
				Saida.mostraMensagem("Cadastro cancelado", "Cadastro de Time");
			}
			
			Saida.mostraMensagemConsole(time.toString());
		} while (Validacao.validaContinua());
		
		Saida.mostraMensagemConsole("Numero de times cadastrados: " + qtdTimes);
	}
}
