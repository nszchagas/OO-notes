package principal;

public class Pessoa {

	public int idade;
	public float altura;
	public String nome;

	// os atributos devem ter qualificador de acesso public ou default (package)
	// para serem acessados nas outras classes
	
	
}
