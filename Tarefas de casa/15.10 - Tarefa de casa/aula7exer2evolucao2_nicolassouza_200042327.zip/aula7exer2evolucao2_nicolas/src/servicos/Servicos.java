package servicos;

import dados.Galeria;
import dados.Pintor;
import dados.Quadro;
import validacao.Validacao;

public class Servicos {
	

}
