package principal;

import dados.Galeria;
import visao.Visao;

public class Principal {
	public static void main(String[] args) {
		// Atributos
		Galeria galeria = new Galeria();

		Visao.menuInicial(galeria);

		// Metodos

	}
}