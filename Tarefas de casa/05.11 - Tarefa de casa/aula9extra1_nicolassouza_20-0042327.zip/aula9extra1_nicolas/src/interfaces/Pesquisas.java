package interfaces;

import java.util.ArrayList;

public interface Pesquisas<A> {

	ArrayList<A> mostraContaminadas(ArrayList<A> colecao, int parametro);
	
}
