package dados;

public class Pessoa {
	private StringBuffer nome;

	public Pessoa(StringBuffer nome) {
		this.nome = nome;
	}

	public StringBuffer getNome() {
		return nome;
	}
}
