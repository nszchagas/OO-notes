package leitura;

import java.util.Scanner;

public class Leitura {

	public static StringBuffer lerNome() {
		Scanner ler = new Scanner(System.in);
		return new StringBuffer(ler.nextLine());
	}

	public static char lerChar() {
		Scanner ler = new Scanner(System.in);
		return ler.next().trim().toUpperCase().charAt(0);
	}

}
