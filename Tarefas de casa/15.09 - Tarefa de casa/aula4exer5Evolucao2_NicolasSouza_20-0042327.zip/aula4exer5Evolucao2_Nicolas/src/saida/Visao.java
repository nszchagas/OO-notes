package saida;

import dados.Pessoa;
import leitura.Leitura;
import servicos.Servicos;
import validacao.Validacao;

public class Visao {

	public static boolean verificaContinuarCadastro() {
		char opcao;

		do {
			System.out.println("Deseja cadastrar um passageiro? (S ou N)");
			opcao = Leitura.lerChar();
		} while (!Validacao.validaContinua(opcao));

		return (opcao == 'S') ? true : false;

	}

	public static StringBuffer cadastraNome() {
		StringBuffer nome;

		do {
			System.out.println("\nCadastre o nome completo do passageiro:");
			nome = Leitura.lerNome();
		} while (!Validacao.validaNome(nome));

		return nome;
	}

	public static void mostraNomeConcatenado(Pessoa pessoa) {
		limpaTela(30);
		System.out.println("O nome do passageiro cadastrado e: "
				+ Servicos.concatenaNomes(Servicos.separaNomes(pessoa.getNome())));
		limpaTela(2);
	}

	public static void mostraMensagemProgramaEncerrado(int qtd) {
		limpaTela(30);
		System.out.println("Programa encerrado com sucesso.");
		System.out.println("O programa formatou, ao todo, o nome de " + qtd + " passageiros.");
	}

	public static void mostraMensagemValorInvalido() {
		System.out.println("O valor digitado esta fora dos parametros estipulados.");
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

	public static void mostraMensagemValorInvalido(int minimo) {
		System.out.println("O valor digitado esta fora dos parametros estipulados! Insira o nome completo.");

	}

}
