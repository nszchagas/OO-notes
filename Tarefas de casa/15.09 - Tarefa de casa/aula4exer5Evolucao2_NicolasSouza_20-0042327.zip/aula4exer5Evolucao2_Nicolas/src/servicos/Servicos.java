package servicos;

public class Servicos {

	public static StringBuffer concatenaNomes(StringBuffer[] nomes) {
		StringBuffer nome = new StringBuffer(nomes[nomes.length - 1].toString().toUpperCase());
		nome.append("/" + nomes[0].toString().toUpperCase());
		return nome;
	}

	public static StringBuffer[] separaNomes(StringBuffer nomeCompleto) {
		String[] nomesAuxiliar = nomeCompleto.toString().trim().split(" ");

		StringBuffer[] nomesSeparados = new StringBuffer[nomesAuxiliar.length];

		for (int aux = 0; aux < nomesAuxiliar.length; aux++) {
			nomesSeparados[aux] = new StringBuffer(nomesAuxiliar[aux]);
		}

		return nomesSeparados;

	}

}
