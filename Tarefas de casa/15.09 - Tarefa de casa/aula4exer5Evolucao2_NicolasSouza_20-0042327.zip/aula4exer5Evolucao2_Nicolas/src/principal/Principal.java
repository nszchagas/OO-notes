package principal;

//import saida.Servicos;
import dados.Pessoa;
import saida.Visao;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {

		int qtdNomesCadastrados = 0;

		while (Visao.verificaContinuarCadastro()) {

			Pessoa pessoa = new Pessoa(Visao.cadastraNome());
			Visao.mostraNomeConcatenado(pessoa);

			qtdNomesCadastrados++;

		}
		
		Visao.mostraMensagemProgramaEncerrado(qtdNomesCadastrados);
	}

}
