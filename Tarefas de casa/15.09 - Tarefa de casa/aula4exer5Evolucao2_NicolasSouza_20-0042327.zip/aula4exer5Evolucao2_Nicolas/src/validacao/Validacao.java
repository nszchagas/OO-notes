package validacao;

import saida.Visao;
import servicos.Servicos;

public class Validacao {

	public static boolean validaNome(StringBuffer nome) {
		final int MINIMO = 3;
		if (nome.toString().trim().isEmpty() || Servicos.separaNomes(nome).length <= 1)
			Visao.mostraMensagemValorInvalido(MINIMO);

		return (!nome.toString().trim().isEmpty() && nome.toString().trim().length() >= MINIMO && Servicos.separaNomes(nome).length > 1);
	}

	public static boolean validaContinua(char opcao) {

		if ((opcao != 'S') && (opcao != 'N')) {
			Visao.limpaTela(30);
			Visao.mostraMensagemValorInvalido();
		}
		return ((opcao == 'S') || (opcao == 'N'));

	}
}