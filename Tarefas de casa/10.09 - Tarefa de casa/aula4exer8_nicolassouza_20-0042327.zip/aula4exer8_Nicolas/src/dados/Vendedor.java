package dados;

public class Vendedor {

	private int[] quantidadeDeVendas;

	public void setVendasSemana(int numSemana, int qtdVendas) {
		this.quantidadeDeVendas[numSemana] = qtdVendas;
	}

	public int[] getVendedor() {
		return this.quantidadeDeVendas;
	}

	public Vendedor(int qtdSemanas) {
		quantidadeDeVendas = new int[qtdSemanas];
	}

}
