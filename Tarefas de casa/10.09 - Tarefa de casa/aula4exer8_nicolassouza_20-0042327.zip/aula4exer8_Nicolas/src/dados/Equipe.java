package dados;

public class Equipe {

	private Vendedor[] equipeVendedores;

	public Equipe(int tamanhoDaEquipe, int qtdSemanas) {
		equipeVendedores = new Vendedor[tamanhoDaEquipe];
		for (int aux = 0; aux < equipeVendedores.length; aux++) // percorre os vendedores da equipe e cada um e criado
																// com tamanho do mes
			equipeVendedores[aux] = new Vendedor(qtdSemanas);

	}
	
	public Vendedor[] getEquipe ()
	{
		return equipeVendedores;
	}
	
	public void setEquipe(Vendedor[] vendedoresRecebidos)
	{
		this.equipeVendedores = vendedoresRecebidos;
	}
	

}
