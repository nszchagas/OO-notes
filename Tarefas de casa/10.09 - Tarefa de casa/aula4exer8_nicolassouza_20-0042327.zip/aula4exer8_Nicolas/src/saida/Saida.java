package saida;

import java.util.InputMismatchException;

import dados.Equipe;
import dados.Vendedor;
import leitura.Leitura;
import servicos.Servicos;
import validacao.Validacao;

public class Saida {

	// ---------------------- REGISTRO DOS N�MEROS
	// ----------------------------------

	public static int registraQuantidadeSemanas() {
		int numSemanas = 0;
		boolean erro = true;
		while (erro) {
			try {
				do {
					System.out.println("Quantas semanas contabeis ha no mes que sera cadastrado?");
					numSemanas = Leitura.getInt();
				} while (!Validacao.validaQuantidadeSemanas(numSemanas));

				erro = false;
			} catch (InputMismatchException excecaoDeFormato) {
				erro = true;
				mostraMensagemTipoErrado();
			}
		}

		limpaTela(30);

		return numSemanas;
	}

	public static int registraVendasCadaVendedor(int codVendedor, int numSemana) {
		int qtdVendas = 0;
		boolean erro = true;

		while (erro) {
			try {
				do {
					mostraMensagemCadastroVendedorEquipe(codVendedor, numSemana);
					qtdVendas = Leitura.getInt();
				} while (!Validacao.validaQuantidadeVendas(qtdVendas));

				erro = false;

			} catch (InputMismatchException excecaoDeFormato) {
				erro = true;
				mostraMensagemTipoErrado();
			}
		}

		limpaTela(30);

		return qtdVendas;
	}

	public static void registraVendedores(Equipe equipe) {

		for (int codVendedor = 0; codVendedor < equipe.getEquipe().length; codVendedor++)
			for (int numSemana = 0; numSemana < equipe.getEquipe()[codVendedor].getVendedor().length; numSemana++)
				equipe.getEquipe()[codVendedor].setVendasSemana(numSemana,
						registraVendasCadaVendedor(codVendedor, numSemana));

	}

	// --------------------- SAIDA DE RESULTADOS --------------------------------

	public static void mostraDados(Equipe equipe) {

		mostraCabecalho(equipe.getEquipe()[0].getVendedor().length);

		for (int codVendedor = 0; codVendedor < equipe.getEquipe().length; codVendedor++) {
			System.out.print(" " + (codVendedor + 1) + " |");
			mostraDadoVendedor(equipe.getEquipe()[codVendedor]);
		}
		
		limpaTela(2);
	}

	public static void mostraDadoVendedor(Vendedor vendedor) {

		for (int aux = 0; aux < vendedor.getVendedor().length; aux++)
			System.out.print("    " + vendedor.getVendedor()[aux] + "     |");
		System.out.println("  " + Servicos.calculaTotalVendasMensal(vendedor));

	}

	public static void mostraCabecalho(int qtdSemanas) {

		System.out.print("N� |");
		for (int aux = 0; aux < qtdSemanas; aux++)
			System.out.print(" Semana " + (aux + 1) + "  |");
		System.out.println(" Total");
	}

	// --------------------- MENSAGENS REAPROVEITAVEIS --------------------------

	public static void mostraMensagemCadastroVendedorEquipe(int codVendedor, int numSemana) {
		System.out.println("Registre a quantidade de vendas do vendedor " + (codVendedor + 1) + " na " + (numSemana + 1)
				+ "� semana:");
	}

	public static void mostraMensagemProgramaEncerrado() {
		System.out.println("Programa encerrado com sucesso.");
	}

	public static void mostraMensagemValorInvalido() {
		System.out.println("O valor digitado esta fora dos parametros estipulados.");
	}

	public static void mostraMensagemValorInvalido(int minimo, int maximo) {
		System.out.println(
				"O valor digitado esta fora dos parametros estipulados (Entre " + minimo + " e " + maximo + ").");

	}

	public static void mostraMensagemValorInvalido(int minimo) {
		System.out.println("O valor digitado esta fora dos parametros estipulados (a partir de " + minimo + ")");

	}

	public static void mostraMensagemTipoErrado() {
		System.out.println("Ocorreu um erro! O valor digitado esta no formato errado.");
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

}
