package servicos;

import dados.Vendedor;

public class Servicos {

	public static int calculaTotalVendasMensal(Vendedor vendedor) {
		int total = 0;
		for (int aux = 0; aux < vendedor.getVendedor().length; aux++)
			total += vendedor.getVendedor()[aux];
		return total;
	}

}
