package leitura;

import java.util.Scanner;

public class Leitura {

	public static String getLinha() {
		Scanner ler = new Scanner(System.in);
		return ler.nextLine();
	}

	public static char getChar() {
		Scanner ler = new Scanner(System.in);
		return (ler.next().trim().toLowerCase().charAt(0));
	}

	public static int getInt() {
		Scanner ler = new Scanner(System.in);
		return ler.nextInt();
	}

}
