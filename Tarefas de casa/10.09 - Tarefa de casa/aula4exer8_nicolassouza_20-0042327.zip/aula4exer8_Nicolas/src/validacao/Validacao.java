package validacao;

import saida.Saida;

public class Validacao {

	public static boolean validaQuantidadeVendas(int quantidade) {
		final int MINIMO = 0;
		if (quantidade < MINIMO)
			Saida.mostraMensagemValorInvalido(MINIMO);
		return (quantidade >= MINIMO);
	}

	public static boolean validaQuantidadeSemanas(int quantidade) {
		final int MAXIMO = 4, MINIMO = 3;
		if (quantidade < MINIMO || quantidade > MAXIMO)
			Saida.mostraMensagemValorInvalido(MINIMO, MAXIMO);
		return (quantidade >= MINIMO && quantidade <= MAXIMO);
	}
}
