package principal;

import dados.Equipe;
import saida.Saida;

public class Principal {

	public static void main(String[] args) {

		final int QUANTIDADE_DE_VENDEDORES = 4;

		Equipe equipe1 = new Equipe(QUANTIDADE_DE_VENDEDORES, Saida.registraQuantidadeSemanas());
		
		Saida.registraVendedores(equipe1);
		Saida.mostraDados(equipe1);
		
		Saida.mostraMensagemProgramaEncerrado();

	}

}
