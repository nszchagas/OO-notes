package principal;

import dados.Pessoa;
import saida.Saida;

public class Principal {

	public static void main(String[] args) {

		while (Saida.verificaContinuarCadastro()) {
			Saida.limpaTela(30);

			Pessoa pessoa1 = new Pessoa(Saida.cadastraNome());
			Saida.limpaTela(2);
			Saida.mostraNomeEmLinhas(pessoa1);
			Saida.limpaTela(2);
		}
		
		Saida.mostraMensagemProgramaEncerrado();

	}

}
