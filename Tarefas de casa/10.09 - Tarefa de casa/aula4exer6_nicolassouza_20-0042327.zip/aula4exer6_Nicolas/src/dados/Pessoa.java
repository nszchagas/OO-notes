package dados;

public class Pessoa {

	private String nome;

	public void setNome(String nomeRecebido) {
		this.nome = nomeRecebido;
	}

	public String getNome() {
		return this.nome;
	}

	public Pessoa(String nomeRecebido) {
		setNome(nomeRecebido);
	}

}
