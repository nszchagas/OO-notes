package saida;

import dados.Pessoa;
import leitura.Leitura;
import servicos.Servicos;
import validacao.Validacao;

public class Saida {

	// --------------------- CADASTRO DE PESSOA --------------------------------

	public static boolean verificaContinuarCadastro() {
		char opcao;

		do {
			System.out.println("Deseja cadastrar uma pessoa? (S ou N)");
			opcao = Leitura.getChar();
		} while (!Validacao.validaContinua(opcao));

		return (opcao == 's') ? true : false;

	}

		public static String cadastraNome() {
		String nome;
		
		do {
			System.out.println("\nCadastre o nome completo da pessoa:");
			nome = Leitura.getLinha();
		} while (!Validacao.validaNome(nome));

		return nome;
	}

	// --------------------- SAIDA DE RESULTADOS --------------------------------

	public static void mostraNomeEmLinhas(Pessoa pessoa) {
		limpaTela(30);
		System.out.println("O nome da pessoa cadastrada e: ");
		mostraNomes(pessoa);
		limpaTela(2);
	}
	
	public static void mostraNomes(Pessoa pessoa)
	{
		for (int aux = 0 ; aux < Servicos.separaNomes(pessoa).length ; aux ++)
			System.out.println(Servicos.separaNomes(pessoa)[aux].toUpperCase());
	}

	// --------------------- MENSAGENS REAPROVEITAVEIS --------------------------

	public static void mostraMensagemProgramaEncerrado() {
		System.out.println("Programa encerrado com sucesso.");
	}

	public static void mostraMensagemValorInvalido() {
		System.out.println("O valor digitado esta fora dos parametros estipulados.");
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

}
