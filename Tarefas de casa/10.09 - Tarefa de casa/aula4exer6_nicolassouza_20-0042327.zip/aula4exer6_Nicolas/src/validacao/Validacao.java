package validacao;

import saida.Saida;

public class Validacao {

	public static boolean validaNome(String nome) {
		if (nome.trim().isEmpty())
			Saida.mostraMensagemValorInvalido();
		return (!nome.trim().isEmpty());

	}

	public static boolean validaContinua(char opcao) {

		if ((opcao != 's') && (opcao != 'n'))
			Saida.mostraMensagemValorInvalido();
		return ((opcao == 's') || (opcao == 'n'));
	}
}
