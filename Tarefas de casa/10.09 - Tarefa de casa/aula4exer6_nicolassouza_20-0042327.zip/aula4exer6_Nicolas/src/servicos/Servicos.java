package servicos;

import dados.Pessoa;

public class Servicos {

	public static String[] separaNomes(Pessoa pessoa1)
	{
		return pessoa1.getNome().split(" ");
	}
	
	
}
