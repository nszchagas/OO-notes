package servicos;

import dados.Pessoa;

public class Servicos {

	public static StringBuilder concatenaNomes(Pessoa pessoa1)
	{
		StringBuilder nome = new StringBuilder(pessoa1.getUltimoNome().toUpperCase());
		
		nome.append(" / " + pessoa1.getPrimeiroNome().toUpperCase());
		
		return nome;
	}
	
	
}
