package dados;

public class Pessoa {

	private String primeiroNome, ultimoNome;

	public void setPrimeiroNome(String nomeRecebido) {
		this.primeiroNome = nomeRecebido;
	}

	public void setUltimoNome(String nomeRecebido) {
		this.ultimoNome = nomeRecebido;
	}

	public String getPrimeiroNome() {
		return this.primeiroNome;
	}

	public String getUltimoNome() {
		return this.ultimoNome;
	}

	public Pessoa(String primeiroNome, String ultimoNome) {
		setPrimeiroNome(primeiroNome);
		setUltimoNome(ultimoNome);
	}

}
