package validacao;

import saida.Saida;

public class Validacao {

	public static boolean validaNome(String nome) {
		if (nome.trim().length() < 3)
			Saida.mostraMensagemValorInvalido();
		return (nome.trim().length() >= 3);
	}

	public static boolean validaContinua(char opcao) {

		if ((opcao != 's') && (opcao != 'n'))
			Saida.mostraMensagemValorInvalido();
		return ((opcao == 's') || (opcao == 'n'));
	}
}
