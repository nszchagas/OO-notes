package saida;

import dados.Pessoa;
import leitura.Leitura;
import servicos.Servicos;
import validacao.Validacao;

public class Saida {

	// --------------------- CADASTRO DE PESSOA --------------------------------

	public static boolean verificaContinuarCadastro() {
		char opcao;

		do {
			System.out.println("Deseja cadastrar um passageiro? (S ou N)");
			opcao = Leitura.getChar();
		} while (!Validacao.validaContinua(opcao));

		return (opcao == 's') ? true : false;

	}

	public static void mostraMensagemCadastro(int numeroDaPessoa) {

		System.out.println("Cadastre os dados do " + (numeroDaPessoa + 1) + "� passageiro abaixo.");
	}

	public static String cadastraNome(int posicaoNome) {
		String nome;
		String posicao = (posicaoNome == 1 ? "primeiro" : "ultimo");

		do {
			System.out.println("\nCadastre o " + posicao + " nome do passageiro:");
			nome = Leitura.getLinha();
		} while (!Validacao.validaNome(nome));

		return nome;
	}

	// --------------------- SAIDA DE RESULTADOS --------------------------------

	public static void mostraNomeConcatenado(Pessoa pessoa) {
		limpaTela(30);
		System.out.println("O nome do passageiro cadastrado e: " + Servicos.concatenaNomes(pessoa));
		limpaTela(2);
	}

	// --------------------- MENSAGENS REAPROVEITAVEIS --------------------------

	public static void mostraMensagemProgramaEncerrado() {
		System.out.println("Programa encerrado com sucesso.");
	}

	public static void mostraMensagemValorInvalido() {
		System.out.println("O valor digitado esta fora dos parametros estipulados.");
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++)
			System.out.println();
	}

}
