package principal;

import dados.Pessoa;
import saida.Saida;

public class Principal {

	public static void main(String[] args) {

		while (Saida.verificaContinuarCadastro()) {
			Pessoa pessoa1 = new Pessoa(Saida.cadastraNome(1), Saida.cadastraNome(2));
			Saida.limpaTela(2);
			Saida.mostraNomeConcatenado(pessoa1);
		}
		
		Saida.mostraMensagemProgramaEncerrado();

	}

}
