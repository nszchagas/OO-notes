package principal;

public class Pessoa {
	// Declaracoes
	public float altura;
	public int idade;
	public String nome;
	
	// Instrucoes
 	 // Metodo construtor
	 Pessoa(String nome, int idade, float altura) {
		this.nome = nome;
		this.idade = idade;
		this.altura = altura;
	 }
}
