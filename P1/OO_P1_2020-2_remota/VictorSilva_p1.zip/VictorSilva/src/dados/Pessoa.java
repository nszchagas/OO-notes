package dados;

public class Pessoa {
	private Integer identificador;
	private StringBuilder nomeCompleto;
	private Character situacaoSaude;

	public Pessoa(Integer identificador, String nomeCompleto, Character situacaoSaude) {
		this.nomeCompleto = new StringBuilder();
		setIdentificador(identificador);
		setNomeCompleto(nomeCompleto);
		setSituacaoSaude(situacaoSaude);
	}

	public void setIdentificador(Integer identificador) {
		this.identificador = identificador;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto.append(nomeCompleto);
	}

	public void setSituacaoSaude(Character situacaoSaude) {
		this.situacaoSaude = situacaoSaude;
	}

	public Integer getIdentificador() {
		return identificador;
	}

	public StringBuilder getNomeCompleto() {
		return nomeCompleto;
	}

	public Character getSituacaoSaude() {
		return situacaoSaude;
	}
}
