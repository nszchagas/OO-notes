package dados;

import java.util.ArrayList;

public class GrupoPessoas {
	private ArrayList<Pessoa> grupoPessoas;

	public GrupoPessoas() {
		this.grupoPessoas = new ArrayList<Pessoa>();
	}

	public void setGrupoPessoas(Pessoa pessoa) {
		this.grupoPessoas.add(pessoa);
	}

	public ArrayList<Pessoa> getGrupoPessoas() {
		return grupoPessoas;
	}

	public int[] getAnalise() {
		int[] quantidades = { 0, 0, 0, 0, 0 };
		for (Pessoa pessoa : getGrupoPessoas()) {
			if (pessoa.getSituacaoSaude() == 'C')
				quantidades[0]++;
			if (pessoa.getSituacaoSaude() == 'T')
				quantidades[1]++;
			if (pessoa.getSituacaoSaude() == 'F')
				quantidades[2]++;
			if (pessoa.getSituacaoSaude() == 'S') {
				if (pessoa instanceof Homem)
					quantidades[3]++;
			}
			if (pessoa.getSituacaoSaude() == 'S') {
				if (pessoa instanceof Mulher)
					quantidades[4]++;
			}
		}
		return quantidades;
	}
}
