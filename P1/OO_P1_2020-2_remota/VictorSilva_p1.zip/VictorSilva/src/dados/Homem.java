package dados;

public class Homem extends Pessoa {
	private Integer idade;

	public Homem(Integer identificador, String nomeCompleto, Character situacaoSaude, Integer idade) {
		super(identificador, nomeCompleto, situacaoSaude);
		setIdade(idade);
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}

	public Integer getIdade() {
		return idade;
	}

	public String toString() {
		String formato = "%-20s%-30s%-30s%-20s%-20s\n";
		return String.format(formato, this.getIdentificador(), this.getNomeCompleto(),
				((this.getSituacaoSaude() == 'T') ? "Contaminada em Tratamento"
						: (this.getSituacaoSaude() == 'F') ? "Contaminada falecida"
								: (this.getSituacaoSaude() == 'C') ? "contaminada Curada" : "Sem contaminacao"),
				this.getIdade(), "---");
	}
}
