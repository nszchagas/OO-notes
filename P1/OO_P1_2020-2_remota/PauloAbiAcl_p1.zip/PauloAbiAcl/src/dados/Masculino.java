package dados;

public class Masculino extends Pessoa{
	private Integer idade;
	public Masculino(Integer codigo, StringBuilder nomeCompleto, Character saude, Integer idade) {
		super(codigo, nomeCompleto, saude);
		this.idade = idade;
	}
	
	public String toString() {
		return String.format("%-25s%-30s%-30s%-20s%-20s\n", getCodigo(), getNomeCompleto(), getSaude(), idade,"---");
	}
	
}
