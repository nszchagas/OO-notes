package dados;

import java.util.ArrayList;

public class Cidade {
	private ArrayList<Pessoa> cidade;

	public Cidade() {
		cidade = new ArrayList<>();
	}

	public void setGrupo(Pessoa pessoa) {
		this.cidade.add(pessoa);
	}

	public ArrayList<Pessoa> getPessoas() {
		return cidade;
	}
}
