package dados;

import java.text.DecimalFormat;

public class Pessoa {
	private StringBuilder nomeCompleto;
	private Integer codigo;
	private Character saude;
	
	public Pessoa (Integer codigo, StringBuilder nomeCompleto, Character saude) {
		this.nomeCompleto = nomeCompleto;
		this.codigo = codigo;
		this.saude = saude;
	}
	public StringBuilder getNomeCompleto() {
		return nomeCompleto;
	}
	public Integer getCodigo() {
		return codigo;
	}
	public Character getSaude() {
		return saude;
	}

	
}
