package dados;

public class Feminino extends Pessoa{
    private Character gestante;
	public Feminino(Integer codigo, StringBuilder nomeCompleto, Character saude, Character gestante) {
		super(codigo, nomeCompleto, saude);
		this.gestante = gestante;
	}

	public String toString() {
		return String.format("%-25s%-30s%-30s%-20s%-20s\n", getCodigo(), getNomeCompleto(), getSaude(), "---", gestante);
	}
}
