package servicos;

import dados.Cidade;
import dados.Feminino;
import dados.Masculino;
import dados.Pessoa;

public class Servicos {
	public static int somaContaminadosM(Cidade cidade) {
		int soma = 0;
		for (Pessoa pessoa : cidade.getPessoas()) {
			if (pessoa instanceof Masculino)
				if (pessoa.getSaude() == 'S') {
					soma++;
				}
		}
		return soma;
	}

	public static int somaContaminadosF(Cidade cidade) {
		int soma = 0;
		for (Pessoa pessoa : cidade.getPessoas()) {
			if (pessoa instanceof Feminino)
				if (pessoa.getSaude() == 'S') {
					soma++;
				}
		}
		return soma;
	}

	public static int somaContaminadosFalecidos(Cidade cidade) {
		int soma = 0;

		for (Pessoa pessoa : cidade.getPessoas()) {
			if (pessoa.getSaude() == 'F') {
				soma++;
			}
		}
		return soma;
	}
	
	public static int somaContaminadosTratamento(Cidade cidade) {
		int soma = 0;

		for (Pessoa pessoa : cidade.getPessoas()) {
			if (pessoa.getSaude() == 'T') {
				soma++;
			}
		}
		return soma;
	}
	
	public static int somaContaminadosCurados(Cidade cidade) {
		int soma = 0;

		for (Pessoa pessoa : cidade.getPessoas()) {
			if (pessoa.getSaude() == 'C') {
				soma++;
			}
		}
		return soma;
	}
}
