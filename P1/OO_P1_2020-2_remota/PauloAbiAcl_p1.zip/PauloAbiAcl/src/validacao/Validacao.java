package validacao;

import java.util.InputMismatchException;

import leitura.Leitura;
import saida.Visao;

public class Validacao {
	
	public static char validaSexo() {
		// Declaracoes
		char sexo;

		// Instrucoes
		do {
			System.out.println(	"Digite o Sexo da pessoa a ser cadastrada('M' para \"masculino\" ou 'F' para \"feminino\") ");
			sexo = Leitura.lerChar();
			Visao.limpaTela(2);
			if ((sexo != 'M') && (sexo != 'F'))
				System.out.print("Opcao invalida! ");
		} while ((sexo != 'M') && (sexo != 'F'));
		return sexo;
	}
	
	public static int validaCodigo() {
		// Declaracoes
		int codigo = 0;
		final int MAIOR = 100;

		// Instrucoes
		do {
			System.out.println("Digite o codigo da pessoa a ser cadastrada: ");
			try {
				codigo = Leitura.lerInt();
				Visao.limpaTela(2);
				if (codigo < MAIOR)
					System.out.println("Valor invalido!codigo tem que ser maior que " + MAIOR);
			} catch (InputMismatchException excecao) {
				System.out.println("Ocorreu um  erro.Digite apenas numeros!");
			}
		} while (codigo <= MAIOR);
		return codigo;
	}
	
	public static StringBuilder validaNome() {

		String lernome;
		StringBuilder nome = new StringBuilder();

		System.out.println("Digite o nome da pessoa: ");
		lernome = Leitura.lerString();

		while (lernome.length() < 3|| lernome.equals(null) || lernome.trim().equals("")) {
			Visao.limpaTela(20);

			if (lernome.equals(null) || lernome.trim().equals("")) {
				System.out.println("Nenhum nome foi informado, por favor informe um nome valido: ");
				lernome = Leitura.lerString();
			} else {
				System.out.print("Nome invalido! O nome deve ter mais de 2 caracteres.\nDigite o nome novamente: ");
				lernome = Leitura.lerString();
			}
		}
		return nome.append(lernome);
	}
	
	public static char validaSaude() {
		// Declaracoes
		char saude;

		// Instrucoes
		System.out.println("Informe a situa��o de sa�de da pessoa, que pode ser: T = contaminada em Tratamento, F = contaminada falecida, C = contaminada Curada e S = Sem contamina��o");
		saude = Leitura.lerChar();

		while ((saude != 'T') && (saude != 'F') && (saude != 'C') && (saude != 'S')) {
			Visao.limpaTela(30);
			System.out.print("Op��o inv�lida! T = contaminada em Tratamento, F = contaminada falecida, C = contaminada Curada e S = Sem contamina��o ");
			saude = Leitura.lerChar();
		}
		Visao.limpaTela(2);
		return saude;
	}
	
	public static int validaIdade() {
		// Declaracoes
		int idade = 0;

		// Instrucoes
		do {
			System.out.println("Digite a Idade do habitante a ser cadastrado ");
			try {
				idade = Leitura.lerInt();
				Visao.limpaTela(2);
				if (idade < 0 || idade >= 151)
					System.out.println("Valor invalido!\nIdade tem que ser maior ou igual a zero e menor que 151");
			} catch (InputMismatchException excecao) {
				System.out.println("Ocorreu um  erro.Digite apenas numeros!");
			}
		} while (idade < 0 || idade >= 151);
		return idade;
	}

	public static char validaGestante() {
		// Declaracoes
		char gestante;

		// Instrucoes
		System.out.println("Informe se essa mulher j� foi gestante (S = sim, N = n�o ou T = n�o tem certeza).");
		gestante = Leitura.lerChar();

		while ((gestante != 'S') && (gestante != 'N') && (gestante != 'T')) {
			Visao.limpaTela(30);
			System.out.print("Op��o inv�lida! S = sim, N = n�o ou T = n�o tem certeza");
			gestante = Leitura.lerChar();
		}
		Visao.limpaTela(2);
		return gestante;
	}
	
	public static int validaOpcao() {
		// Declaracoes
		boolean erro = false;
		int opcao = 0;

		// Instrucoes
		do {
			System.out.println("OP��ES DE APRESENTA��O: ");
			System.out.println("1 = Registro novo");
			System.out.println("2 = Relat�rio de todos registros");
			System.out.println("0 = Sair");
			System.out.print("Digite sua opcao:");
			try {
				opcao = Leitura.lerInt();
				if (opcao < 0 || opcao > 2) {
					Visao.limpaTela(2);
					System.out.println("Valor inv�lido!");
					erro = true;
				} else
					erro = false;
			} catch (InputMismatchException excecao) {
				Visao.limpaTela(2);
				System.out.println("Ocorreu um  erro.");
				erro = true;
			}
		} while (erro);
		return opcao;
	}
	
	
}
