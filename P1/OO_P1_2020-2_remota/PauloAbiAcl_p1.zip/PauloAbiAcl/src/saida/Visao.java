package saida;

import java.text.DecimalFormat;

import dados.Cidade;
import dados.Pessoa;
import servicos.Servicos;

public class Visao {

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++) {
			System.out.println();
		}
	}
	
	public static void mostraRelatorio(Cidade cidade) {
		System.out.format("%-25s%-30s%-30s%-20s%-20s\n", "Identificador"," Nome completo", "Situa��o de sa�de", "Idade", "Gestante");
		for (Pessoa pessoa: cidade.getPessoas()) {
			System.out.println(pessoa);
		}
	}
	
	public static void mostraResultado(Cidade cidade) {
		DecimalFormat formata = new DecimalFormat("00");
		System.out.println(formata.format(Servicos.somaContaminadosCurados(cidade)) + " = CONTAMINADOS CURADOS");
		System.out.println(formata.format(Servicos.somaContaminadosTratamento(cidade)) + " = CONTAMINADOS EM TRATAMENTO");
		System.out.println(formata.format(Servicos.somaContaminadosFalecidos(cidade)) + " = CONTAMINADOS FALECIDOS");
		System.out.println(formata.format(Servicos.somaContaminadosM(cidade)) + " = HOMENS SEM CONTAMINA��O");
		System.out.println(formata.format(Servicos.somaContaminadosF(cidade)) + " = MULHERES SEM CONTAMINA��O");
		System.out.println("___________________________________________________________________");
		System.out.println(formata.format(cidade.getPessoas().size()) + "= TOTAL DE REGISTRO DE PESSOAS");
	}
}
