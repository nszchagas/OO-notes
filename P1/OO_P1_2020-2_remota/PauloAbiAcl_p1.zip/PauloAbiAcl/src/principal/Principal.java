package principal;

//Nome Completo:Paulo Vitor Silva Abi-Acl    Data da Prova:20/10/2020

import dados.Cidade;
import dados.Feminino;
import dados.Masculino;
import saida.Visao;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {
		Cidade cidade = new Cidade();
		int opcao = 0;

		do {
			switch (opcao = Validacao.validaOpcao()) {
			case 1: {
				if (Validacao.validaSexo() == 'M')
					cidade.setGrupo(new Masculino(Validacao.validaCodigo(), Validacao.validaNome(),
							Validacao.validaSaude(), Validacao.validaIdade()));
				else
					cidade.setGrupo(new Feminino(Validacao.validaCodigo(), Validacao.validaNome(),
							Validacao.validaSaude(), Validacao.validaGestante()));
				Visao.limpaTela(10);

				break;
			}
			case 2: {
				Visao.mostraRelatorio(cidade);
				Visao.limpaTela(20);
				break;
			}
			case 0: {
				Visao.limpaTela(40);
				Visao.mostraResultado(cidade);
				break;
			}
			}
		} while (opcao != 0);

	}

}
