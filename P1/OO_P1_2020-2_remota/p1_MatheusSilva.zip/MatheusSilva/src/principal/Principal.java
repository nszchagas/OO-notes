package principal;

import java.util.ArrayList;

import dados.Paciente;
import dados.Pessoa;
import leitura.Leitura;
import saida.Saida;
import validacao.Valida;

public class Principal {

	public static void main(String[] args) {
		// Nome Completo: Matheus Henrique de Araujo Silva Data da Prova: 20/10/2020
		boolean continua = false;
		ArrayList<Pessoa> pessoas = new ArrayList<Pessoa>();
		ArrayList<Paciente> pacientes = new ArrayList<Paciente>();

		do {
			continua = false;
			Saida.mostraMenu();
			char opcao = Valida.validaOpcao();

			if (opcao == '1') {
				char opcaoCadastro = Valida.validaOpcaoCadastro();
				if (opcaoCadastro == '1') {
					Pessoa pessoa = new Pessoa(Valida.geraID(), Valida.pedeNome(), Valida.pedeGenero(),
							Valida.pedeIdade());
					pessoas.add(pessoa);
				} else if (opcaoCadastro == '2') {
					Paciente paciente = new Paciente(Valida.geraID(), Valida.pedeNome(), Valida.pedeGenero(),
							Valida.pedeSituacao());
					pacientes.add(paciente);
				}
				continua = true;
			} else if (opcao == '2') {
				Saida.saltaLinhasConsole(10);
				Saida.mostraCadastrados(pessoas, pacientes);
				continua = true;
			} else if (opcao == '0') {
				Saida.saltaLinhasConsole(50);
				Saida.relatorioFinal(pessoas, pacientes);
				continua = false;
			}
		} while (continua);

	}

}
