package dados;

public class Paciente extends Pessoa {
	private Character situacao;

	public Paciente(Integer id, String nome, Character genero, Character situacao) {
		super(id, nome, genero, 0);
		setSituacao(situacao);
	}

	// m�todo get
	public Character getSituacao() {
		return this.situacao;
	}

	// m�todo set
	public void setSituacao(Character situacao) {
		this.situacao = situacao;
	}

	// Sobrescrita do m�todo toString para imprimir facilmente os objetos da classe
	public String toString() {
		String generoExtenso;
		if (this.genero == 'm') {
			generoExtenso = "Masculino";
		} else {
			generoExtenso = "Feminino";
		}
		return ("\tID: " + getID() + "\tNome: " + getNome() + "\tG�nero: " + generoExtenso + "\tSitua��o do Paciente: "
				+ getSituacao());
	}

}
