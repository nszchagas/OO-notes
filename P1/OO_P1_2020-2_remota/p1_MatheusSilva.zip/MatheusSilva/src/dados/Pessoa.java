package dados;

public class Pessoa {
	private Integer id;
	private String nome;
	protected Character genero;
	private Integer idade;

	public Pessoa(Integer id, String nome, Character genero, Integer idade) {
		setID(id);
		setNome(nome);
		setGenero(genero);
		setIdade(idade);
	}

	// m�todos get
	public Integer getID() {
		return this.id;
	}

	public String getNome() {
		return this.nome;
	}

	public Character getGenero() {
		return this.genero;
	}

	public Integer getIdade() {
		return this.idade;
	}

	// m�todos set
	public void setID(Integer id) {
		this.id = id;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setGenero(Character genero) {
		this.genero = genero;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}

	// Sobrescrita do m�todo toString para imprimir facilmente os objetos da classe
	public String toString() {
		String generoExtenso;
		if (this.genero == 'm') {
			generoExtenso = "Masculino";
		} else {
			generoExtenso = "Feminino";
		}
		return ("\tID: " + getID() + "\tNome: " + getNome() + "\tG�nero: " + generoExtenso + "\tIdade: " + getIdade());
	}

}
