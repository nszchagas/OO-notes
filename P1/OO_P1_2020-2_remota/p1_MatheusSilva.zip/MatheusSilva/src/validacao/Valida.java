package validacao;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import leitura.Leitura;
import saida.Saida;

public class Valida {
	public static Integer geraID() {
		final int MINIMO = 1;
		Random random = new Random();
		return random.nextInt() + MINIMO;
	}

	public static String pedeNome() {
		String nome;
		boolean erro;

		do {
			erro = false;
			System.out.println("Insira o nome a se cadastrar: ");
			nome = Leitura.lerString();

			if (nome == null || nome.length() < 3) {
				erro = true;
				System.out.println("Insira um nome com mais de 3 caract�res para continuar com o cadastros! ");

			}
		} while (erro);

		return nome;
	}

	public static Character pedeGenero() {
		char genero;
		boolean erro;

		do {
			erro = false;
			System.out.println("Insira 'M' para g�nero 'Masculino' ou 'F' para 'Feminino': ");
			genero = Leitura.lerChar();

			if (genero != 'm' && genero != 'f') {
				erro = true;
				System.out
						.println("Insira 'M' para 'Masculino' ou 'F' para 'Feminino' para continuar com o cadastros! ");

			}
		} while (erro);

		return genero;
	}

	public static Integer pedeIdade() {
		int idade = 0;
		boolean erro;

		do {
			erro = false;
			try {
				System.out.println("Insira a idade da pessoa: ");
				idade = Leitura.lerInt();
				if (idade < 0 || idade > 130) {
					erro = true;
					System.out.println("Insira idades entre 0 e 130 anos para continuar com os cadastros! ");
				}
			} catch (InputMismatchException e) {
				erro = true;
				System.out.println("Tipo de dado inv�lido, insira apenas n�meros inteiros! ");
			}
		} while (erro);

		return idade;
	}

	public static Character pedeSituacao() {
		char situacao;
		boolean erro;

		do {
			erro = false;
			System.out.println(
					"Insira por favor a situa��o do paciente, sendo:\n 'E' para 'em tratamento', 'F' para 'falecido' ou 'C' para 'curado' ");
			situacao = Leitura.lerChar();

			if (situacao != 'e' && situacao != 'f' && situacao != 'c') {
				erro = true;
				System.out.println("Erro, tente novamente.");
			}
		} while (erro);

		return situacao;
	}

	public static Boolean continua() {
		char opcao = Leitura.lerChar();
		if (opcao == 0) {
			return true;
		} else {
			return false;
		}
	}

	public static char validaOpcao() {
		char opcao;
		boolean erro;

		do {
			erro = false;
			System.out.println("Insira a op��o do menu: ");
			opcao = Leitura.lerChar();
			if (opcao != '1' && opcao != '2' && opcao != '0') {
				erro = true;
				System.out.println("Insira apenas as op��es dispon�veis no menu! ");
			}
		} while (erro);
		return opcao;
	}

	public static char validaOpcaoCadastro() {
		char opcao;
		boolean erro;
		do {
			Saida.mostraMenuOp��oCadastro();
			opcao = Leitura.lerChar();
			erro = false;
			if (opcao != '1' && opcao != '2') {
				erro = true;
				System.out.println("Insira apenas as op��es dispon�veis no menu! ");
			}
		} while (erro);
		return opcao;
	}
}
