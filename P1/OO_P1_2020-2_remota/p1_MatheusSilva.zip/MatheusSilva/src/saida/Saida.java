package saida;

import java.util.ArrayList;

import dados.Paciente;
import dados.Pessoa;

public class Saida {
	public static void saltaLinhasConsole(int linhasPuladas) {
		for (int aux = 0; aux < linhasPuladas; aux++)
			System.out.println();
	}

	public static void mostraMenu() {
		System.out.println("1 - Novo cadastro\n2 - Mostrar todos cadastros\n0 - Encerrar");
	}

	public static void mostraMenuOp��oCadastro() {
		saltaLinhasConsole(10);
		System.out.println("1 - Pessoa que nunca pegou Covid\n2 - Pessoa que tem hist�rico com Covid");
	}

	public static void mostraCadastrados(ArrayList<Pessoa> pessoas, ArrayList<Paciente> pacientes) {
		if (pessoas.size() > 0) {
			System.out.println("Pessoas cadastradas: ");
			for (Pessoa pessoa : pessoas) {
				System.out.println(pessoa);
			}
		}
		if (pacientes.size() > 0) {
			System.out.println("Pacientes cadastrados: ");
			for (Paciente paciente : pacientes) {
				System.out.println(paciente);
			}
		}
	}

	public static void relatorioFinal(ArrayList<Pessoa> pessoas, ArrayList<Paciente> pacientes) {
		int nContamidado = pessoas.size();
		int contamidadoEmTratamento = 0;
		int contamidadoCurado = 0;
		int mulheresContaminadasFalecidas = 0;
		int homensContaminadosFalecidos = 0;
		int total = nContamidado + pacientes.size();

		for (Paciente paciente : pacientes) {
			if (paciente.getSituacao() == 'e') {
				contamidadoEmTratamento++;
			} else if (paciente.getSituacao() == 'f' && paciente.getGenero() == 'm') {
				homensContaminadosFalecidos++;
			} else if (paciente.getSituacao() == 'f' && paciente.getGenero() == 'f') {
				mulheresContaminadasFalecidas++;
			} else if (paciente.getSituacao() == 'c') {
				contamidadoCurado++;
			}
		}
		System.out.println(nContamidado + " = N�O CONTAMINADO" + "\n" + contamidadoEmTratamento
				+ " = CONTAMINADOS EM TRATAMENTO" + "\n" + contamidadoCurado + " = CONTAMINADOS CURADOS" + "\n"
				+ mulheresContaminadasFalecidas + " = MULHERES CONTAMINADAS FALECIDAS" + "\n"
				+ homensContaminadosFalecidos + " = HOMENS CONTAMINADOS FALECIDOS");
		System.out.println("_______________________________________________________________________________");
		System.out.println(total + " = TOTAL DE PESSOAS CADASTRADAS");
	}
}
