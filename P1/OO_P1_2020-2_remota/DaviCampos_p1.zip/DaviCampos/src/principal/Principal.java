//Nome Completo: Davi Marinho da Silva Campos     Data da Prova: 20/10/2020

package principal;

import servicos.Servicos;

public class Principal {

	public static void main(String[] args) {
		Servicos.mostraMenu();
	}
}
