package dados;

public class Contaminada extends Pessoa{
	private String situacaoSaude;
	
	public Contaminada(String nome, String genero, Integer codigo, String situacaoSaude) {
		super(nome, genero, codigo);
		this.situacaoSaude = situacaoSaude;
	}
	
	public String getSituacaoSaude() {
		return this.situacaoSaude;
	}
	
	public String toString() {
		String formato = "%-15s|%-20s|%-10s|%-10s|%s";
		
		return String.format(formato, this.getCodigo(), this.getNome(), this.getGenero(), "---", this.getSituacaoSaude());

	}

}
