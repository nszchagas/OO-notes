package dados;

public class NaoContaminada extends Pessoa{
	private Integer idade;
	
	public NaoContaminada(String nome, String genero, Integer codigo, Integer idade) {
		super(nome, genero, codigo);
		this.idade = idade;
	}
	
	public Integer getIdade() {
		return this.idade;
	}
	
	public String toString() {
		String formato = "%-15s|%-20s|%-10s|%-10s|%s";
		
		return String.format(formato, this.getCodigo(), this.getNome(), this.getGenero(), this.getIdade(), "---");

	}

}
