package dados;

import java.util.ArrayList;

public class Grupo {
	private ArrayList<Pessoa> grupo;

	public Grupo() {
		this.grupo = new ArrayList<Pessoa>();
	}

	public void setPessoa(Pessoa pessoa) {
		this.grupo.add(pessoa);
	}

	public ArrayList<Pessoa> getGrupo() {
		return this.grupo;
	}

	public boolean checaIgualdadeCodigo(int codigo) {
		if (this.getGrupo().isEmpty()) {
			return false;
		} else {
			for (Pessoa pessoa : this.getGrupo()) {
				if (pessoa.getCodigo() == codigo) {
					return true;
				}
			}
			return false;
		}
	}
	
	public int qtdQtdNaoContaminados() {
		int total = 0;
		for(Pessoa pessoa : this.getGrupo()) {
			if(pessoa instanceof NaoContaminada) {
				total++;
			}
		}
		return total;
	}
	
	public int getQtdContaminadosTratamento() {
		int total = 0;
		for(Pessoa pessoa : this.getGrupo()) {
			if(pessoa instanceof Contaminada) {
				if(((Contaminada) pessoa).getSituacaoSaude().equals("Em tratamento"))
					total++;
			}
		}
		return total;
	}
	
	public int getQtdContaminadosCurados() {
		int total = 0;
		for(Pessoa pessoa : this.getGrupo()) {
			if(pessoa instanceof Contaminada) {
				if(((Contaminada) pessoa).getSituacaoSaude().equals("Curado"))
					total++;
			}
		}
		return total;
	}
	
	public int getMulheresContaminadasFalecidas() {
		int total = 0;
		for(Pessoa pessoa : this.getGrupo()) {
			if(pessoa instanceof Contaminada) {
				if(pessoa.getGenero().equals("Feminino") &&((Contaminada) pessoa).getSituacaoSaude().equals("Falecido"))
					total++;
			}
		}
		return total;
	}
	
	public int getHomensContaminadosFalecidos() {
		int total = 0;
		for(Pessoa pessoa : this.getGrupo()) {
			if(pessoa instanceof Contaminada) {
				if(pessoa.getGenero().equals("Masculino") &&((Contaminada) pessoa).getSituacaoSaude().equals("Falecido"))
					total++;
			}
		}
		return total;
	}
}
