package visao;

import java.util.ArrayList;

import dados.Grupo;
import dados.Pessoa;

public class Visao {

	public static void mostraMensagem(String mensagem) {
		System.out.println(mensagem);
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++) {
			System.out.println();
		}
	}

	public static void mostraMensagemErro(String mensagem) {
		System.err.println(mensagem);
	}

	public static void mostraTabela(Grupo pessoas) {
		String formato = "%-10s%-30s%-10s%-20s%-10s%-20s\n";
		System.out.format(formato, "IDENTIFICADOR", "NOME", "GENERO", "IDADE", "SITUACAO SAUDE");
		Visao.mostraMensagem("============================================================");
		for (int i = 0; i < pessoas.getPessoas().size(); i++ ) {
			System.out.println(pessoas.toString());
		}
	}

}
