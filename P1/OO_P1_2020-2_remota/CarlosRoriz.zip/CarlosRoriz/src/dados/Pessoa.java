package dados;

import validacao.Validacao;
import visao.Visao;

public class Pessoa {
	
	private String nome;
	private String genero;
	private Integer idade;
	private Boolean situacaoMedica;
	private Integer identificador; //fazer um cont no principal
	private String situacaoSaude;

	
	
	
	public Pessoa(String nome, String genero, boolean situacaoMedica, Integer idade, String situacaoSaude, Integer identificador) {
		
		setNome(nome);
		setGenero(genero);
		setIdade(idade);
		setSituacaoMedica(situacaoMedica);
		setIdentificador(identificador);
		setSituacaoSaude(situacaoSaude);
	}
	
	




	public Pessoa() {
		Pessoa pessoa = new Pessoa();
		
	}






	public String getNome() {
		return nome;
	}




	public void setNome(String nome) {
		this.nome = nome;
	}




	public String getGenero() {
		return genero;
	}




	public void setGenero(String genero) {
		this.genero = genero;
	}




	public Integer getIdade() {
		return idade;
	}




	public void setIdade(Integer idade) {
		this.idade = idade;
	}




	public Boolean getSituacaoMedica() {
		return situacaoMedica;
	}




	public void setSituacaoMedica(Boolean situacaoMedica) {
		this.situacaoMedica = situacaoMedica;
	}




	public Integer getIdentificador() {
		return identificador;
	}




	private void setIdentificador(Integer identificador) {
		this.identificador = identificador;
	}




	public String getSituacaoSaude() {
		return situacaoSaude;
	}




	public void setSituacaoSaude(String situacaoSaude) {
		this.situacaoSaude = situacaoSaude;
	}


	public void cadastraPessoa(Integer contadorIdentificador) {
		Validacao.validaNome("Informe o nome da pessoa");
		Validacao.validaSexo("Inform o sexo da pessoa, 'F' para feminino, e 'M' para masculino");
		Validacao.validaSituacaoMedica("Entre com a situacao da pessoa, 'P' para positivado com COVID-19, e 'N' para negativo ");
		if(getSituacaoMedica() == false) {
			Validacao.validaIdade("Informe a idade da pessoa");
			setSituacaoSaude(null);
		}else
			setIdade(null);
			Validacao.validaSituacaoSaude("Informe como esta o quadro de saude do paciente, 'E' para (em tratamento), 'F' para (falecido), e 'C' para curado");
			
		setIdentificador(contadorIdentificador);
		
		
	}

	@Override
	public String toString() {
		String formato = "%-10s%-30s%-10s%-20s%-10s%-20s\n"; //identificador, nome,  genero, idade situacao
		
		return String.format(formato, this.getIdentificador(), this.getNome(), this.getGenero(), this.getIdade(), this.getSituacaoSaude() );
	}
	
	
	
	

}
