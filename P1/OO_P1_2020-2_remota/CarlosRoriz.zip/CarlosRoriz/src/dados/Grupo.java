package dados;

import java.util.ArrayList;

public class Grupo {
	ArrayList<Pessoa> pessoas;
	
	public Grupo () {
		this.pessoas = new ArrayList<Pessoa>();
	}
	
	public ArrayList<Pessoa> getPessoas (){
		return pessoas;
	}
	
	public Pessoa getPessoa (int posicao){
		return pessoas.get(posicao);
	}
	
	public void setPessoa(Pessoa pessoa) {
		this.pessoas.add(pessoa);
	}
	
}
