package validacao;

import java.util.InputMismatchException;

import leitura.Leitura;
import visao.Visao;

public class Validacao {

	public static int validaMenuRegistros() {
		int opcao = -1;
		Visao.mostraMensagem("Informe a opcao desejada: " + 
		" \n1 - CADASTRAR PESSOA " + 
		"\n2 - MOSTRAR TABELA" +
		"\n0 - ENCERRAR CADASTROS");	
		try {
			opcao = Integer.parseInt(Leitura.lerEntrada());
			if(opcao < 0 || opcao > 3) {
				Visao.mostraMensagemErro("Valor invalido! Insira um numero de 0 a 2");
				opcao = validaMenuRegistros();
			}
		}catch(InputMismatchException e) {
			Visao.mostraMensagemErro("Entrada invalida! A entrada deve ser numerica");
			opcao = validaMenuRegistros();
		}
		
		return opcao;
	}
	
	public static String validaNome(String mensagem) {
		// Declaracoes
		String nome = "";

		// Instrucoes

		nome = Leitura.lerEntradaTexto(mensagem);
		Visao.limpaTela(2);
		if (nome.isEmpty() || nome.length() <= 3) {
			Visao.mostraMensagemErro(
					"O nome n�o pode ser vazio, e deve possuir mais que 3 caracteres! Tente novamente: ");
			nome = validaNome(mensagem);
		}
			for (int i = 0; i < nome.length(); i++) {
				if (Character.isAlphabetic(i) == false) {
					Visao.mostraMensagemErro("O nome deve conter apenas letras");
				}
			}
		
		return nome;
	}
	
	public static String validaSexo(String mensagem) {
		// Declaracoes
		String sexo = "";
		
		// Instrucoes

		sexo = Leitura.lerEntradaTexto(mensagem);
		Visao.limpaTela(2);
		if(!sexo.toLowerCase().equals("f") || !sexo.toLowerCase().equals("m")) {
			Visao.mostraMensagemErro("Entrada invalida ! Entre com 'M' para masculino ou 'F' para feminino");
			validaSexo(mensagem);
		}
		
		if (sexo.isEmpty() ) {
			Visao.mostraMensagemErro(
					"A entrada nao pode ser vazia ! Voce deve entrar com o sexo ");
			sexo = validaNome(mensagem);
		}
		
		if(sexo.toLowerCase().equals("f"))
			sexo = "feminino";
		if(sexo.toLowerCase().equals("m"))
			sexo = "masculino";

		return sexo;
	}
	
	public static int validaIdade(String mensagem) { // so pegar idade para as pesseas negativadas
		int idade = 0;
		
		try { // try catch eu vou utilizr s� em int e float
			idade = Leitura.lerInteiro(mensagem);
			if (idade < 0 || idade > 130) {
				Visao.mostraMensagemErro("Erro ! A idade deve estar entre 0 e 130 ");
				idade = validaIdade(mensagem); // 
			}
			
			if(Integer.toString(idade).isEmpty()) {
				Visao.mostraMensagemErro("Erro ! A entrada nao pode ser vazia");
				idade = validaIdade(mensagem);
			}
		} catch (NumberFormatException e) {
			Visao.mostraMensagemErro("Erro, a entrada deve ser numerica! Tente novamente: ");
			idade = validaIdade(mensagem); 
		}
		return idade;
				
	}
	
	public static boolean validaSituacaoMedica(String mensagem) {
		boolean opcao = false;
		Visao.mostraMensagem(mensagem);
		char entrada = Leitura.lerEntrada().charAt(0);
		if (!("pnPN").contains(Character.toString(entrada))) { 
			Visao.mostraMensagemErro("Entrada invalida, utilize 'P' pra POSITIVO ou 'n' para NEGATIVO");
			opcao = validaSituacaoMedica();
		}

		if (entrada == 'p' || entrada == 'p') {
			opcao = true;
		} else {
			opcao = false;
		}

		return opcao;
	}
	
	public static String validaSituacaoSaude(String mensagem) {
		String situacao = "";
		
		Visao.mostraMensagem(mensagem);
		char entrada = Leitura.lerEntrada().charAt(0);
		if (!("efcEFC").contains(Character.toString(entrada))) {
			Visao.mostraMensagemErro("Entrada invalida, utilize 'E' pra em tratamento ou 'F' para falecido e 'C' para curado");
			situacao = validaSituacaoSaude(mensagem);
		}
		
		if(situacao.toLowerCase().equals("e"))
			situacao = "Em tratameto";
		if(situacao.toLowerCase().equals("f"))
			situacao = "Falecido";
		if(situacao.toLowerCase().equals("c"))
			situacao = "Curado";
		
			

		return situacao;
	}
	
	
	
	
	

}
