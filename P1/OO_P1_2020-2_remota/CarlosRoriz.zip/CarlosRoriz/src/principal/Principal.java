package principal;

import dados.Grupo;
import dados.Pessoa;
import validacao.Validacao;
import visao.Visao;

public class Principal {

	public static void main(String[] args) {
		//1novo cadastro
		// 2 mostrar todos cadastrados
		//0 encerrar e mostrar resultados
		
		Grupo pessoas = new Grupo();
		Pessoa pessoa = new Pessoa();
		
		int escolha;
		int identificador = 0;
			
			do {
				
				escolha = Validacao.validaMenuRegistros();
				switch(escolha) {
				case 1: pessoa.cadastraPessoa(identificador);
				break;
				case 2: Visao.mostraTabela(pessoas);
				break;
				}
				
			}while(escolha != 0);
			
			Visao.mostraResultados(pessoas);
			
		

	}

}
