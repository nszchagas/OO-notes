package leitura;

import java.util.Scanner;

import visao.Visao;

public class Leitura {
	public static String lerEntrada(String mensagem) {
		Visao.mostraMensagem(mensagem);
		return new Scanner(System.in).nextLine().trim(); //
	}

	public static String lerEntrada() {
		return new Scanner(System.in).nextLine().trim(); //
	}

	public static String lerEntradaTexto(String mensagem) {
		Visao.mostraMensagem(mensagem);
		return new Scanner(System.in).nextLine(); // utilizo esse m�todo quando a entrada eh um texto com mais de uma
													// string
	}

	public static int lerInteiro(String mensagem) {
		Visao.mostraMensagem(mensagem);
		return new Scanner(System.in).nextInt();
	}

	public static float lerFloat(String mensagem) {
		Visao.mostraMensagem(mensagem);
		return new Scanner(System.in).nextFloat();

	}
}
