package dados;

import java.util.ArrayList;

public class Populacao {
		
		public ArrayList<Pessoa> populacao;
		
		
		public Populacao() {
			populacao = new ArrayList<Pessoa>();
			
		}
		
		public void setGrupoMamiferos(Pessoa pessoa) {
			this.populacao.add(pessoa);
		}
		
		public ArrayList<Pessoa> getPopulacao(){
			return populacao;
		}
	
}
