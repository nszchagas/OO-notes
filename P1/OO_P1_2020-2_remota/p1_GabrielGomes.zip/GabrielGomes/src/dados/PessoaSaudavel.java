package dados;

import validacao.Validacao;

public class PessoaSaudavel extends Pessoa {

	Integer idade;
	
	public PessoaSaudavel(String nome, Character genero, Integer identificador, Integer idade) {
		super(nome, genero, identificador);
		setIdade(idade);
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}
	
	public static void registraPessoa(Populacao populacao) {
		PessoaSaudavel pessoasaudavel = new PessoaSaudavel(Validacao.validaNome(), 'm', 1, 10); /*,
				Validacao.validaInteiro("Digite a idade geral de amamenta��o materna do elefante (em anos)"),
				Validacao.validaDescricao("Descreva brevemente a especie do elefante"),
				Validacao.validaFloat("Digite o tamanho normal do elefante na fase adulta (valor em metros):"),
				Validacao.validaFloat("Digite o peso do elefante (em toneladas)"),
				Validacao.validaDescricao("Descreva o habitat natural desse elefante"));
		grupoMamiferos.setGrupoMamiferos(elefante);*/
	}
	
}
