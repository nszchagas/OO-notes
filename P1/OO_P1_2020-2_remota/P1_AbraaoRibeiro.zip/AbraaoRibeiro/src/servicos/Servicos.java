package servicos;

public class Servicos {

	public static int naoContaminados() {
		return 0;
	}
	public static int contaminados() {
		return 0;
	}public static int curados() {
		return 0;
	}public static int mulheresFalecidas() {
		return 0;
	}public static int homemsFalecidos() {
		return 0;
	}

	



}
