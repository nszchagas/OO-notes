package dados;

public class Masculino extends Pessoa {

	private Integer idade;

	public Masculino(String nomeCompleto, String saude, Integer idade) {
		super(nomeCompleto, saude);
		this.setIdade(idade);
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}

	@Override
	public String toString() {
		String formato = "%-30s %-20s %-20s %-20s\n";
		return String.format(formato, this.getNomeCompleto(), this.getSaude(), this.idade, "---");
	}

}
