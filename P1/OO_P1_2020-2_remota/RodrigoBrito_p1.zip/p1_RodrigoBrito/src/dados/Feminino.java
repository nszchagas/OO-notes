package dados;

public class Feminino extends Pessoa {

	private String gestante;

	public Feminino(String nomeCompleto, String saude, String gestante) {
		super(nomeCompleto, saude);
		this.gestante = gestante;
	}

	public String getGestante() {
		return gestante;
	}

	public void setGestante(String gestante) {
		this.gestante = gestante;
	}

	@Override
	public String toString() {
		String formato = "%-30s %-20s %-20s %-20s\n";

		return String.format(formato, this.getNomeCompleto(), this.getSaude(), "---", this.getGestante());
	}

}
