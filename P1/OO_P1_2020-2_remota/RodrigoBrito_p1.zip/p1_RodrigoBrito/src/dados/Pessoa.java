package dados;

//Nome completo, Situa��o de sa�de por extenso, Idade e Gestante por extenso,
public class Pessoa {

	private String nomeCompleto;
	private String saude;

	public Pessoa(String nomeCompleto, String saude) {
		this.setNomeCompleto(nomeCompleto);
		this.setSaude(saude);
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}

	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getSaude() {
		return saude;
	}

	public void setSaude(String saude) {
		this.saude = saude;
	}

}
