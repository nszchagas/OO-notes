// Nome Completo: Rodrigo Balbino Azevedo de Brito Data da Prova: 20/10/2020

package principal;

import dados.Grupo;
import saida.Visao;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {

		Grupo grupo = new Grupo();
		int escolha = 0;
		do {
			escolha = Validacao.mostraMenu();
			switch (escolha) {
			case 0:
				Visao.limpaTela(40);
				Validacao.validaContabiliza(grupo.getPessoas());
				break;
			case 1:
				Visao.limpaTela(40);
				Validacao.validaNovaPessoa(grupo);
				break;
			case 2:
				Visao.limpaTela(40);
				Visao.mostrarCadastros(grupo.getPessoas());
				break;
			}
		} while (escolha != 0);
	}
}
