package saida;

import java.util.ArrayList;
import dados.Pessoa;

public class Visao {

	public static void mostrarCadastros(ArrayList<Pessoa> pessoas) {
		
		String formato = "%-30s %-20s %-20s %-20s\n";
		System.out.format(formato, "Nome", "Saude", "Idade", "Gestante");
		System.out.println("===========================================================================");
		for (Pessoa pessoa : pessoas) {
			System.out.println(pessoa);
		}
	}

	public static void limpaTela(int linhas) {
		for (int i = 0; i < linhas; i++) {
			System.out.println();
		}
	}

}
