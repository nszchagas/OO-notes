package validacao;

import java.util.ArrayList;
import java.util.InputMismatchException;
import dados.Feminino;
import dados.Grupo;
import dados.Masculino;
import dados.Pessoa;
import leitura.Leitura;

public class Validacao {

	public static int mostraMenu() {
		int escolha = -1;
		System.out.println(
				"Escolha uma das opcoes: \n[0]= Sair\n[1] = Registra novo\n[2] Relatorio de todos os registros");
		do {
			try {
				escolha = Leitura.lerInt();
				if (escolha != 0 & escolha != 1 & escolha != 2) {
					System.err.println("\n[0]= Sair\n[1] = Registra novo\n[2] Relatorio de todos os registros");
				}
			} catch (InputMismatchException e) {
				System.err.println(
						"Digite um numeral!\n[0]= Sair\n[1] = Registra novo\n[2] Relatorio de todos os registros");
			}
		} while (escolha != 0 && escolha != 1 && escolha != 2);
		return escolha;
	}

	public static void validaNovaPessoa(Grupo pessoas) {
		System.out
				.println("Deseja registrar uma pessoa de qual sexo?\n Digite [0] para feminino ou  [1] para masculino");
		switch (validaOpcao()) {
		case 0:
			Feminino feminino = new Feminino(validaNome(), validaSaude(), validaGestante());

			pessoas.setPessoas(feminino);
			break;
		case 1:
			Masculino masculino = new Masculino(validaNome(), validaSaude(), validaIdade());
			pessoas.setPessoas(masculino);
			break;
		}

	}

	public static int validaOpcao() {
		int opcao = -1;
		
		do {
			opcao = Leitura.lerInt();
			try {
				if (opcao != 0 && opcao != 1) {
					System.out.println("Digite [0] para feminino ou [1] para masculino");
				}
			} catch (InputMismatchException e) {
				System.out.println("Digite [0] para feminino ou [1] para masculino");
			}

		} while (opcao != 0 && opcao != 1);
		return opcao;
	}

	public static String validaNome() {
		String nome;
		do {
			System.out.println("Digite o nome da pessoa");
			nome = Leitura.lerString();
			if (nome.isBlank() || nome.isEmpty() || validaNumeroNome(nome)) {
				System.out.println("Escreva um nome valido!!");
			}
		} while (nome.isBlank() || nome.isEmpty() || validaNumeroNome(nome));
		return nome;
	}

	public static boolean validaNumeroNome(String nome) {
		for (char palavra : nome.toCharArray()) {
			if (Character.isDigit(palavra)) {
				return true;
			}
		}
		return false;
	}

//T = contaminada em Tratamento, F = contaminada falecida, C = contaminada Curada e S = Sem contamina��o
	public static String validaSaude() {

		System.out.println(
				"Escolha uma das opcoes de saude da pessoa: \nT = contaminada em tratamento\nF = contaminada e falecida\nC = contaminada e curada\n S = Sem contaminacao");

		switch (validaLetra()) {
		case 'T':
			return "Contaminada em Tratamento";
		case 'F':
			return "Contaminada e Falecida";

		case 'C':
			return "Contaminada e Curada";
		case 'S':
			return "Sem contaminacao";
		}
		return "nada";
	}

	public static char validaLetra() {
		char opcao = 'g';
		opcao = Leitura.lerChar();
		do {
			try {
				if (opcao != 'T' && opcao != 'F' && opcao != 'C' && opcao != 'S') {
					System.out.println(
							"Escolha entre:\nT = contaminada em tratamento\nF = contaminada e falecida\nC = contaminada e curada\n S = Sem contaminacao");
				}
			} catch (InputMismatchException e) {
				System.out.println(
						"Digite uma letra!\nT = contaminada em tratamento\nF = contaminada e falecida\nC = contaminada e curada\n S = Sem contaminacao");
			}

		} while (opcao != 'T' && opcao != 'F' && opcao != 'C' && opcao != 'S');

		return opcao;
	}

	public static char validaOpcaoGestante() {
		char opcao;

		do {
			opcao = Leitura.lerChar();
			if (opcao != 'S' && opcao != 'N' && opcao != 'T') {
				System.out.println(
						"Escolha uma das opcoes: \n\" S se ja foi gestante\\n N se nunca foi gestante \\n T se nao tem certeza\"");
			}
		} while (opcao != 'S' && opcao != 'N' && opcao != 'T');

		return opcao;
	}

	public static String validaGestante() {

		System.out.println("Digite S se ja foi gestante\nDigite N se nunca foi gestante \nDigite T se nao tem certeza");

		switch (validaLetra()) {
		case 'S':
			return "Ja foi gestante";
		case 'N':
			return "Nunca foi gestante";

		case 'T':
			return "Nao tem certeza";
		}
		return "nada";
	}

	public static int validaIdade() {
		int idade = 0;
		System.out.println("Digite em anos a idade do homem");
		do {
			try {
				idade = Leitura.lerInt();
				if (idade < 0 || idade > 150) {
					System.out.println("A idade deve ser maior do que zero e menor que 150");
				}
			} catch (InputMismatchException Exception) {
				System.out.println("Deve escrever um numeral!");
			}
		} while (idade <= 0);
		return idade;
	}

	public static void validaContabiliza(ArrayList<Pessoa> pessoas) {
//		39 = CONTAMINADOS CURADOS
//				21 = CONTAMINADOS EM TRATAMENTO
//				13 = CONTAMINADOS FALECIDOS
//				07 = HOMENS SEM CONTAMINA��O
//				09 = MULHERES SEM CONTAMINA��O
//				89 = TOTAL DE REGISTRO DE PESSOAS
		int curados = 0;
		int tratamento = 0;
		int falecidos = 0;
		int semContaminar = 0;

		for (int i = 0; i < pessoas.size(); i++) {
			if (pessoas.get(i).getSaude().equalsIgnoreCase("Contaminada e Falecida")) {
				falecidos++;
			} else if (pessoas.get(i).getSaude().equalsIgnoreCase("Contaminada em Tratamento")) {
				tratamento++;
			} else if (pessoas.get(i).getSaude().equalsIgnoreCase("Contaminada e Curada")) {
				curados++;
			} else if (pessoas.get(i).getSaude().equalsIgnoreCase("Sem contaminacao")) {
				semContaminar++;
			}
		}

		System.out.println(curados + " CONTAMINADOS CURADOS\n" + tratamento + " CONTAMINADOS EM TRATAMENTO\n" + falecidos
				+ " CONTAMINADOS FALECIDOS\n" + semContaminar + " SEM CONTAMINACAO" + pessoas.size()
				+ " TOTAL DE REGISTRO DE PESSOAS");
	}
}
