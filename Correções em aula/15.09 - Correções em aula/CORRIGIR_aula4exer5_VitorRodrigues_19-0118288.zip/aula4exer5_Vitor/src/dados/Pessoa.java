package dados;

public class Pessoa {
	private String nome;

	public Pessoa(String nome) {
		this.nome = nome;
	}

	public String getString() {
		return nome;
	}
}
