package saida;

public class Servicos {

	public static void limpaTela(int linhas) {

		for (int i = 0; i <= linhas; i++) {
			System.out.println("");
		}
	}

}
