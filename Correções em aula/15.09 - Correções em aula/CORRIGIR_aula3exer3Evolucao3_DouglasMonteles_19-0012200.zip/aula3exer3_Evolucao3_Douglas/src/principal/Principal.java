package principal;

import dados.Grupo;
import dados.Pessoa;
import servicos.Servicos;
import servicos.Validacao;

public class Principal {
	public static void main(String[] args) {
		// Declaracoes
		final int LIMITE = 50;
		int contaPessoa = 0;
		
		Grupo grupo = new Grupo(); 
		
		// Procedimentos
		do {
			System.out.println("Pessoa [" + (++contaPessoa) + "] de [" + LIMITE + "]\n");
			
			Pessoa pessoa = new Pessoa();
			
			System.out.println("Informe um nome:");
			pessoa.setNome(Validacao.validaNome());
			
			System.out.println("Informe uma idade:");
			pessoa.setIdade(Validacao.validaIdade());
			
			System.out.println("Informe uma altura:");
			pessoa.setAltura(Validacao.validaAltura());
			
			grupo.setGrupo(pessoa);
		
			Servicos.limpaTela(50);
		} while (Validacao.validaContinua(contaPessoa, LIMITE));
		
		Servicos.mostraDados(grupo);
	}
}
