package dados;

import java.util.ArrayList;

public class Grupo {

	private ArrayList<Pessoa> grupo;
	
	public Grupo() {
		grupo = new ArrayList<>(); 
	}

	public ArrayList<Pessoa> getGrupo() {
		return grupo;
	}

	public void setGrupo(Pessoa pessoa) {
		this.grupo.add(pessoa);
	}
	
}
