package exer3aula3;

public class Pessoa {

	private  String nome;
	private  int idade;
	private  float altura;
	
	
	
	
	protected  String getNome() {
		return nome;
	}
	protected  void setNome(String nome) {
		this.nome = nome;
	}
	protected  int getIdade() {
		return idade;
	}
	protected  void setIdade(int idade) {
		this.idade = idade;
	}
	protected  float getAltura() {
		return altura;
	}
	protected  void setAltura(float altura) {
		this.altura = altura;
	}
		
}
