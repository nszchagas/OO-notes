/*
#include <stdio.h>

int main(void) {
    // DECLARACOES
    const int MAX = 3;
    float alturaA = 1.58;
    float alturaB = 2.07;
    float alturaC = 0.55;
    float media;
    
	// INSTRUCOES
    media = (alturaA + alturaB + alturaC) / MAX;
    printf("Media das alturas: %.3f\n", media);
    return 0;
}
*/

package primeiro;

import java.text.DecimalFormat;

public class AlturaMedia {
	public static void main(String[] args) {
		// DECLARACOES
	    final int MAX = 3;
	    float alturaA = 1.58F;
	    float alturaB = 2.07F;
	    float alturaC = 0.55F;
	    float media;
	    DecimalFormat mascara = new DecimalFormat("0.000");
	    
	    // INSTRUCOES
	    media = (alturaA + alturaB + alturaC) / MAX;
	    System.out.println("Media das alturas:" + mascara.format(media));
	}
}
