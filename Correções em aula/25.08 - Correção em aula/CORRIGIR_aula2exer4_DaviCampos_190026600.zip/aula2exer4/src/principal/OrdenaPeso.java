package principal;

import java.text.DecimalFormat;
import java.util.Scanner;

public class OrdenaPeso {

	public static void main(String[] args) {
		// DECLARACOES
		final int MAX = 3;
		final int PESOMINIMO = 5;
		DecimalFormat mascara = new DecimalFormat("#0.00");
		float[] peso = new float[MAX];
		Scanner ler = new Scanner(System.in);

		// INSTRUCOES
		for (int contador = 0; contador < MAX; contador++) {
			System.out.println("Digite o peso do " + (contador + 1) + " elefante:");
			peso[contador] = ler.nextFloat();
			while (peso[contador] < PESOMINIMO) {
				System.out.println("Peso Invalido! Informe peso maior "
						+ PESOMINIMO + ".");
				peso[contador] = ler.nextFloat();
			}
		}
		System.out.println("\n\n Pesos Gravados \n\n");
		for (int aux = 0; aux < MAX; aux++) {
			System.out.println("Peso [" + (aux + 1) + "] = "
					+ mascara.format(peso[aux]));
		}
	}
}
