package dados;

import java.util.ArrayList;

public class Alunos {
	private ArrayList<Aluno> alunos;
	
	public Alunos() {
		alunos = new ArrayList<Aluno>();
	}
	
	public ArrayList<Aluno> getAlunos() {
		return this.alunos;
	}
	
	public Aluno getAluno(int i) {
		return alunos.get(i);
	}
	
	public void setAluno(Aluno aluno) {
		this.alunos.add(aluno);
	}
}
