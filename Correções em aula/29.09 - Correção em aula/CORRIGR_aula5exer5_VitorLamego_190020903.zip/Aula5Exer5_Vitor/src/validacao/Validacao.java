package validacao;

import java.util.ArrayList;
import java.util.InputMismatchException;

import dados.Aluno;
import dados.Alunos;
import leitura.Leitura;
import saida.Visao;

public class Validacao {
	public static String validaNome() {
		String nome;
		boolean erro;
		
		System.out.println("\n-------------------------------CADASTRO-------------------------------");
		do {
			erro = false;
			System.out.print("Digite o nome completo do aluno: ");
			nome = Leitura.leString();
			
			if (nome.isEmpty()) {
				System.out.println("\nNome inválido !! Não é aceito deixar esse campo em branco");
				erro = true;
			}
		} while(erro);
		return nome;
	}
	
	public static int validaMatricula(Alunos alunos) {
		int matricula = 0;
		boolean erro;
		final int MAX = 1000;
		ArrayList<Aluno> alunosCadastrados = alunos.getAlunos();
		
		do {
			try {
				erro = false;
				System.out.print("Digite a matrícula do aluno: ");
				matricula = Leitura.leInteiro();
				
				if(matricula < MAX) {
					System.out.println("\nNúmero de matrícula inválido !! Digite novamente.");
					erro = true;
				}
				else {
					for(int i = 0; i < alunosCadastrados.size(); i++) {
						if(alunosCadastrados.get(i).getMatricula() == matricula) {
							System.out.println("\nMatrícula já existente !! Impossível cadastrar outro aluno com a mesma matrícula.");
							erro = true;
							break;
						}
					}
				}
				
			} catch (InputMismatchException e) {
				System.out.println("\nFormato de matrícula inválido !! Digite somente os números da matrícula");
				erro = true;
			}
		}while(erro);
		
		return matricula;
	}
	
	public static float validaMedia() {
		float media = -1f;
		boolean erro;
		
		do {
			try {
				erro = false;
				System.out.print("Digite a média final do aluno: ");
				media = Leitura.leFloat();
				
				if(media < 0 || media > 10) {
					System.out.println("\nMédia inválida !! O valor deve estar entre 0 e 10 !!");
					erro = true;
				}
			} catch(InputMismatchException e) {
				System.out.println("Formato inválido de média !! Se atente ao número inserido. Caso escreva número decimal utilize ',' e não '.' !!\n");
				erro = true;
			}
		}while(erro);
		Visao.limpaConsole(1);
		
		return media;
		
	}
	
	public static boolean isContinuaCadastro(){
		char continua;
		boolean erro;
		
		do {
			erro = false;
			System.out.print("Deseja cadastrar mais um aluno ? Digite 'Sim' ou 'Não' para escolher: ");
			continua = Leitura.leCaracter();
			
			if(continua != 'S' && continua != 'N') {
				System.out.println("Opção inválida !!\n");
				erro = true;
			}
		}while(erro);
		
		if(continua=='S') {
			Visao.limpaConsole(20);
			return true;
		}
		return false;
	}
	
	public static float validaMediaGeral(Alunos alunos) {
		float soma = 0f;
		ArrayList<Aluno> alunosCadastrados = alunos.getAlunos();
		
		for(int i=0; i < alunosCadastrados.size(); i++)
			soma += alunosCadastrados.get(i).getMediaAritmetica();
		
		return soma/alunosCadastrados.size();
	}
}











