package principal;

import dados.*;
import saida.Visao;
import validacao.Validacao;

public class Cadastro {
	public static void main(String[] args) {
		Alunos alunos = new Alunos();
		
		while(Validacao.isContinuaCadastro()) {
			Aluno aluno = new Aluno(Validacao.validaNome(), Validacao.validaMatricula(alunos), Validacao.validaMedia());
			alunos.setAluno(aluno);
		}
		
		Visao.mostraRelatorio(alunos);
	}
}
