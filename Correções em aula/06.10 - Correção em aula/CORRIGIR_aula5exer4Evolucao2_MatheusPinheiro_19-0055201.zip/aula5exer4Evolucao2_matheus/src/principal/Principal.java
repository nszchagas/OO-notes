package principal;

import dados.*;
import saida.Visao;
import validacao.Validacao;

public class Principal {
	public static void main(String[] args) {
		Grupo grupo = new Grupo();

		do {
			
			do {
				Pessoa pessoa = new Pessoa(Validacao.validaNome());
				grupo.setNomes(pessoa);
				Visao.limpaTela(2);
			}while (Validacao.validaCadastroNome());
			Visao.limpaTela(50);
		} while (Validacao.validaNovoGrupo());
		Visao.mostraMensagem("A ultima lista teve " + grupo.getNomes().size() + " nomes cadastrados");
	}
}
