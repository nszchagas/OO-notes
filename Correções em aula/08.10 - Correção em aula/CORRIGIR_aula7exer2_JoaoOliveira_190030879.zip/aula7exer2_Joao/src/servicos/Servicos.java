package servicos;

import dados.Galeria;
import dados.Pintor;
import dados.Quadro;
import validacao.Validacao;

public class Servicos {
	public static void registraPintor (Galeria galeria) {
		galeria.setPintor(new Pintor(
			Validacao.validaNome("Determine o nome do Pintor:"), 
			Validacao.validaCodigoPessoal(galeria, "Determine o codigo do Pintor:"), 
			Validacao.validaAno("Determine o ano de nascimento do pintor:")
		));
	}
	
	public static void registraQuadro (Galeria galeria) {
		galeria.setQuadro(new Quadro(
			Validacao.validaCodigoQuadro(galeria, "Determine o codigo do Quadro:"), 
			Validacao.validaCodigoPintor(galeria, "Determine o codigo do Pintor responsavel pelo quadro:"), 
			Validacao.validaPreco("Determine o preco do quadro: [0 caso tenha sido doado]"), 
			Validacao.validaAno("Determine o ano da compra do quadro:")
		));
	}
	
	public static int achaCodigoPintor (Galeria galeria, String nome) {
		for (Pintor pintor : galeria.getListaPintores()) {
			if (pintor.getNome().toUpperCase().contains(nome.toUpperCase())) {
				return pintor.getCodigoPessoal();
			}
		}
		return -1;
	}
}
