package interfaces;

public interface Pesquisas {

	void mostraContaminadas(int quantidade); // Nao entendi bem a questao do primeiro parametro

	boolean isContaminadosMaior(int quantidade);

}