package dados;

import java.util.ArrayList;

public class ColecaoCidades {

	private ArrayList<Cidade> cidades;

	public ColecaoCidades() {
		this.cidades = new ArrayList<Cidade>();
	}
	
	public ArrayList<Cidade> getCidades() {
		return cidades;
	}
	
}
