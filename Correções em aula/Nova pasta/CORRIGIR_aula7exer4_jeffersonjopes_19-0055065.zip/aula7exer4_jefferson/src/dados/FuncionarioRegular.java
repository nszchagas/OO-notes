package dados;

public class FuncionarioRegular extends Funcionario {

	public FuncionarioRegular(String nome, String cpf, String dataDeNascimento) {
		super(nome, cpf, dataDeNascimento);
	}

	public float calculaSalario() { // PISO SALARIAL ACRESCIDO DE 10%
		return (this.getPISO() + (this.getPISO() / 10));
	}

	public String toString() {
		String formato = "%-20s%-10s%-30s%-10s%-10s%-10s\n";
		return String.format(formato, this.getNome(), this.getCategoria(), this.getCpf(), this.getDataDeNascimento(),
				"---", "---");
	}

	public String getCategoria() {
		return "Regular";
	}
}
