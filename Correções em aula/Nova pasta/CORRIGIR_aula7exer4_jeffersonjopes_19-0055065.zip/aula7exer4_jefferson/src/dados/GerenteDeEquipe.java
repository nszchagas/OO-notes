package dados;

public class GerenteDeEquipe extends Funcionario {
	private Integer quantidadeDeProjetos;

	public GerenteDeEquipe(String nome, String cpf, String dataDeNascimento, int quantidadeDeProjetos) {
		super(nome, cpf, dataDeNascimento);
		setQuantidadeDeProjetos(quantidadeDeProjetos);
	}

	public Integer getQuantidadeDeProjetos() {
		return quantidadeDeProjetos;
	}

	public void setQuantidadeDeProjetos(Integer quantidadeDeProjetos) {
		this.quantidadeDeProjetos = quantidadeDeProjetos;
	}

	public float calculaSalario() { // QTD DE PROJETOS VEZES 50% DO PISO SALARIAL ACRESCIDO DO PROPRIO PISO
		return (this.getQuantidadeDeProjetos() * ((this.getPISO() + this.getPISO()) / 2));
	}

	public String toString() {
		String formato = "%-20s%-10s%-30s%-10s%-10s%-10s\n";
		return String.format(formato, this.getNome(), this.getCategoria(), this.getCpf(), this.getDataDeNascimento(),
				"---", this.getQuantidadeDeProjetos());
	}

	public String getCategoria() {
		return "Gerente";
	}

}
