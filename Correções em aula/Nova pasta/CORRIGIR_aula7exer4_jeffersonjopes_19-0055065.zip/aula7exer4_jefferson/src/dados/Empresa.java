package dados;

import java.text.DecimalFormat;
import java.util.ArrayList;

import saida.Saida;

public class Empresa {
	private ArrayList<Funcionario> funcionarios;

	public Empresa() {
		this.funcionarios = new ArrayList<Funcionario>();
	}

	public void criaFuncionario() {
		this.funcionarios = new ArrayList<Funcionario>();
	}

	public ArrayList<Funcionario> getFuncionarios() {
		return funcionarios;
	}

	public void setFuncionarios(Funcionario funcionario) {
		this.funcionarios.add(funcionario);
	}

	public void cadastraRegular(String nome, String cpf, String nascimento) {
		this.setFuncionarios(new FuncionarioRegular(nome, cpf, nascimento));
	}

	public void cadastraPrestador(String nome, String cpf, String nascimento, int horas) {
		this.setFuncionarios(new PrestadorDeServicos(nome, cpf, nascimento, horas));
	}

	public void cadastraGerente(String nome, String cpf, String nascimento, int projetos) {
		this.setFuncionarios(new GerenteDeEquipe(nome, cpf, nascimento, projetos));
	}

	public int getQuantidadeFuncionariosPorCategoria(String codigo) {
		int contador = 0;

		for (Funcionario funcionario : getFuncionarios()) {
			if (funcionario.getCategoria().equals(codigo))
				contador++;
		}
		return contador;
	}

	public void resultado(int codigo) {
		String formato = "%-20s%-10s\n";
		DecimalFormat mascara = new DecimalFormat("0.00");
		Saida.limpaTela(40);
		if (codigo == 1) {
			System.out.format(formato, "CATEGORIA", "FUNCIONARIOS");
			System.out.format(formato, "REGULAR", getQuantidadeFuncionariosPorCategoria("Regular"));
			System.out.format(formato, "PRESTADOR", getQuantidadeFuncionariosPorCategoria("Prestador"));
			System.out.format(formato, "GERENTE", getQuantidadeFuncionariosPorCategoria("Gerente"));
		}
		if (codigo == 2) {
			System.out.format(formato, "CATEGORIA", "FUNCIONARIOS");
			System.out.format(formato, "REGULAR", mascara.format(getSalarioPorCategoria("Regular")));
			System.out.format(formato, "PRESTADOR", mascara.format(getSalarioPorCategoria("Prestador")));
			System.out.format(formato, "GERENTE", mascara.format(getSalarioPorCategoria("Gerente")));
		}
		Saida.limpaTela(2);
	}

	public float getSalarioPorCategoria(String codigo) {
		float total = 0F;

		for (Funcionario funcionario : getFuncionarios())
			if (funcionario.getCategoria().equals(codigo))
				total += funcionario.getPISO();
		return total;
	}

	public void exibirRelatorio() {
		String formato = "%-20s%-10s%-10s%-20s%-10s\n";
		System.out.format(formato, "NOME", "CATEGORIA", "CPF", "HORAS TRABALHADAS", "PROJETOS");
		for (Funcionario funcionario : getFuncionarios())
			System.out.println(funcionario);
	}

}
