package validacao;

import java.util.ArrayList;
import java.util.InputMismatchException;

import dados.Funcionario;
import leitura.Leitura;
import saida.Saida;

public class Validacao {

	public static String validaNome() {
		Saida.limpaTela(40);
		Saida.exibirMensagemCadastroDeFuncionario();

		Saida.solicitarNome();
		String nome = Leitura.lerLinha();

		while (nome.split(" ")[0].equals(nome)) {
			Saida.informarNomeInvalido();
			nome = Leitura.lerLinha();
		}

		return nome;
	}

	public static String validaCpf(ArrayList<Funcionario> empresa) {
		String cpf;
		boolean erro = false;

		Saida.solicitarCpf();
		do {
			cpf = Leitura.lerString();

			while (cpf.length() != 11 || !verificaDigitos(cpf)) {
				Saida.informarCpfInvalido();
				cpf = Leitura.lerString();
			}

			int contador = 0;
			while (contador < empresa.size()) {
				if (empresa.get(contador++).getCpf().equals(cpf)) {
					System.err.println("CPF ja inserido!!");
					erro = true;
					break;
				}
			}

		} while (erro);

		return cpf;
	}

	public static boolean verificaDigitos(String palavra) {

		for (char c : palavra.toCharArray()) {
			if (!('0' <= c && c <= '9')) {
				return false;
			}
		}
		return true;
	}

	public static String validaDataDeNascimento() {
		int dia, mes, ano;

		dia = validaDia();
		mes = validaMes();
		ano = validaAno();

		return Integer.toString(dia) + "/" + Integer.toString(mes) + "/" + Integer.toString(ano);

	}

	public static int validaDia() {
		int dia;

		Saida.solicitarDiaDeNascimento();
		try {
			dia = Leitura.lerInt();

			while (!(dia > 0 && dia <= 30)) {
				Saida.informarDiaDeNascimentoInvalido();
				dia = validaDia();
			}
		} catch (InputMismatchException e) {
			Saida.informarExcecaoInt();
			dia = validaDia();
		}
		return dia;
	}

	public static int validaMes() {
		int mes;

		Saida.solicitarMesDeNascimento();
		try {
			mes = Leitura.lerInt();

			while (!(mes > 0 && mes <= 12)) {
				Saida.informarMesDeNascimentoInvalido();
				mes = validaMes();
			}
		} catch (InputMismatchException e) {
			Saida.informarExcecaoInt();
			mes = validaMes();
		}
		return mes;
	}

	public static int validaAno() {
		int ano;

		Saida.solicitarAnoDeNascimento();
		try {
			ano = Leitura.lerInt();

			while (!(ano > 0 && ano <= 2020)) {
				Saida.informarAnoDeNascimentoInvalido();
				ano = validaAno();
			}
		} catch (InputMismatchException e) {
			Saida.informarExcecaoInt();
			ano = validaAno();
		}
		return ano;
	}

	public static int validaHorasTrabalhadas() {
		int horas;

		Saida.solicitarHorasTrabalhadas();
		try {
			horas = Leitura.lerInt();

			while (!(horas > 0 && horas <= 220)) {
				Saida.informarHorasTrabalhadasInvalida();
				horas = validaHorasTrabalhadas();
			}
		} catch (InputMismatchException e) {
			Saida.informarExcecaoInt();
			horas = validaHorasTrabalhadas();
		}
		return horas;
	}

	public static int validaProjetos() {
		int projetos;

		Saida.solicitarQuantidadeDeProjetos();
		try {
			projetos = Leitura.lerInt();

			while (!(projetos > 0 && projetos <= 220)) {
				Saida.informarQuantidadeDeProjetosInvalido();
				projetos = validaProjetos();
			}
		} catch (InputMismatchException e) {
			Saida.informarExcecaoInt();
			projetos = validaProjetos();
		}
		return projetos;
	}

	public static int validaMenuDeFuncionarios() {
		int opcao;

		do {
			Saida.exibirMenuDeFuncionarios();

			try {
				opcao = Leitura.lerInt();
				if (opcao < 0 || opcao > 3) {
					System.err.println("Valor Invalido! Insira um numero de 0 a 3");
					opcao = validaMenuDeFuncionarios();
					System.out.println("teste " + opcao);

				}
			} catch (InputMismatchException e) {
				System.err.println("Valor Invalido! Insira apenas um numero");
				opcao = validaMenuDeFuncionarios();
			}
		} while (opcao < 0 || opcao > 3);

		return opcao;
	}

	public static int validaMenu() {
		int opcao;

		do {
			Saida.exibirMenu();

			try {
				opcao = Leitura.lerInt();
				if (opcao < 0 || opcao > 2) {
					System.err.println("Valor Invalido! Insira um numero de 0 a 2");
					opcao = validaMenu();

				}
			} catch (InputMismatchException e) {
				System.err.println("Valor Invalido! Insira apenas um numero");
				opcao = validaMenu();
			}
		} while (opcao < 0 || opcao > 2);
		return opcao;
	}
}
