package principal;

import dados.Empresa;
import saida.Saida;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {
		int opcao;
		Empresa empresa = new Empresa();

		do {
			opcao = Validacao.validaMenuDeFuncionarios();
			switch (opcao) {
			case 1:
				empresa.cadastraRegular(Validacao.validaNome(), Validacao.validaCpf(empresa.getFuncionarios()),
						Validacao.validaDataDeNascimento());
				break;
			case 2:
				empresa.cadastraPrestador(Validacao.validaNome(), Validacao.validaCpf(empresa.getFuncionarios()),
						Validacao.validaDataDeNascimento(), Validacao.validaHorasTrabalhadas());
				break;
			case 3:
				empresa.cadastraGerente(Validacao.validaNome(), Validacao.validaCpf(empresa.getFuncionarios()),
						Validacao.validaDataDeNascimento(), Validacao.validaProjetos());
			}
		} while (opcao != 0);

		empresa.exibirRelatorio();
		do {
			opcao = Validacao.validaMenu();
			empresa.resultado(opcao);
		} while (opcao != 0);

	}
}
