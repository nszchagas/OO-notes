package saida;

public class Saida {

	public static void solicitarNome() {
		System.out.print("\nInforme o nome do funcionario: ");
	}

	public static void informarNomeInvalido() {
		System.err.println("\nNome invalido! Informe tambem o sobrenome.");
	}

	public static void solicitarCpf() {
		System.out.print("\nInforme o CPF do funcionario: ");
	}

	public static void informarCpfInvalido() {
		System.err.println("\nCPF invalido! Informe exatamente 11 digitos. Apenas digitos sao permitidos.");
	}

	public static void solicitarDiaDeNascimento() {
		System.out.print("Informe o numero correspondente ao dia de nascimento: ");
	}

	public static void informarDiaDeNascimentoInvalido() {
		System.err.println("\nDia de nascimento invalido! Informe um dia maior que 0 e menor que 31.");
	}

	public static void solicitarMesDeNascimento() {
		System.out.println("\n(Janeiro = 1; Dezembro = 12;)");
		System.out.print("Informe o numero correspondente ao mes de nascimento: ");
	}

	public static void informarMesDeNascimentoInvalido() {
		System.err.println("\nMes de nascimento invalido! Informe um mes maior que 0 e menor que 13.");
	}

	public static void solicitarAnoDeNascimento() {
		System.out.print("Informe o numero correspondente ao ano de nascimento: ");
	}

	public static void informarAnoDeNascimentoInvalido() {
		System.err.println("\nAno de nascimento invalido! Informe um ano maior que 0 e menor que 2021.");
	}

	public static void informarExcecaoInt() {
		System.err.println("\nEntrada invalida! Insira apenas um numero inteiro.");
	}

	public static void solicitarHorasTrabalhadas() {
		System.out.print("Informe a quantidade de horas trabalhadas: ");
	}

	public static void informarHorasTrabalhadasInvalida() {
		System.err.print("Quantidade de horas trabalhadas invalida, insira um valor maior que 0 e menor que 221");
	}

	public static void solicitarQuantidadeDeProjetos() {
		System.out.print("Informe a quantidade de projetos trabalhados: ");
	}

	public static void informarQuantidadeDeProjetosInvalido() {
		System.err.print("Quantidade de projetos invalido, insira um valor maior ou igual a 0 e menor que 100");
	}

	public static void exibirMenuDeFuncionarios() {
		System.out.println("\nInforme a opcao desejada:");
		System.out.println("1 - CADASTRAR FUNCIONARIO REGULAR");
		System.out.println("2 - CADASTRAR PRESTADOR DE SERVICOS");
		System.out.println("3 - CADASTRAR GERENTE DE EQUIPE");
		System.out.println("0 - ENCERRAR CADASTRO");
	}

	public static void exibirMenu() {
		Saida.limpaTela(1);
		System.out.println("Informe a opcao desejada:");
		System.out.println("1 - VISUALIZAR O TOTAL DE FUNCIONARIOS CADASTRADOS EM CADA CATEGORIA");
		System.out.println("2 - VISUALIZAR O TOTAL SALARIAL A SER PAGO PARA CADA CATEGORIA");
		System.out.println("0 - ENCERRAR O PROGRAMA");
	}

	public static void limpaTela(int linhasPuladas) {
		for (int aux = 0; aux < linhasPuladas; aux++)
			System.out.println();
	}

	public static void exibirMensagemCadastroDeFuncionario() {
		System.out.println("CADASTRO DE FUNCIONARIO");
	}

}
