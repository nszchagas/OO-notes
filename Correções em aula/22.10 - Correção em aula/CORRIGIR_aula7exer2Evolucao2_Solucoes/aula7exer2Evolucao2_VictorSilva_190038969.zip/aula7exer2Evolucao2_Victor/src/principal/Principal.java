package principal;

import dados.*;
import saida.Visao;
import validacao.Validacao;

public class Principal {
	public static void main(String[] args) {
		// Declaracoes
		final int ANOMINIMO = 1000;
		final int ATUAL = 2020;
		Galeria galeria = new Galeria();
		int escolha;

		// Instrucoes
		do {
			String[] opcao = { "Cadastrar Novo Pintor", "Cadastrar Novo Quadro", "Pesquisar obras de um pintor",
					"Mostrar quadros cadastrados", "Encerrar programa" };
			escolha = Visao.mostraMenu(opcao);
			if (galeria.getListaPintores().isEmpty() && escolha != 0 && escolha != 4)
				Visao.mensagemAtencao("Cadastre ao menos um pintor!", "Atencao");
			else {
				switch (escolha) {
				case 0:
					registraPintor(galeria, ANOMINIMO, ATUAL);
					break;
				case 1:
					registraQuadro(galeria, ANOMINIMO, ATUAL);
					break;
				case 2:
					Visao.mostraQuadrosNome(galeria,
							Validacao.validaNome("Digite o nome a ser procurado:", "Pesquisa"));
					break;
				case 3:
					Visao.mostraQuadros(galeria);
				}
			}
		} while (escolha != 4);
	}

	// Outros metodos
	public static void registraPintor(Galeria galeria, final int ANOMINIMO, final int ATUAL) {
		galeria.setListaPintores(new Pintor(Validacao.validaNome("Determine o nome do Pintor:", "Cadastro"),
				Validacao.validaCodigoPessoal(galeria, "Determine o codigo do Pintor:"),
				Validacao.validaAno("Determine o ano de nascimento do pintor:", ANOMINIMO, ATUAL)));
	}

	public static void registraQuadro(Galeria galeria, final int ANOMINIMO, final int ATUAL) {
		int id;
		galeria.setListaQuadros(new Quadro(Validacao.validaCodigoQuadro(galeria, "Determine o codigo do Quadro:"),
				id = Validacao.validaCodigoPintor(galeria, "Determine o codigo do Pintor responsavel pelo quadro:",
						ANOMINIMO, ATUAL),
				Validacao.validaPreco("Determine o preco do quadro: [0 caso tenha sido doado]"), Validacao.validaAno(
						"Determine o ano da compra do quadro:", Validacao.validaAnoMinimo(id, galeria), ATUAL)));
	}
}