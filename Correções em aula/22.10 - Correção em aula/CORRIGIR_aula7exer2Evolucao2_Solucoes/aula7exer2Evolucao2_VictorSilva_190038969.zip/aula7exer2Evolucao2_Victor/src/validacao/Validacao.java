package validacao;

import dados.Galeria;
import dados.Pintor;
import dados.Quadro;
import leitura.Leitura;
import principal.Principal;
import saida.Visao;

public class Validacao {
	public static String validaNome(String mensagem, String titulo) {
		String nome = null;

		do {
			try {
				nome = Leitura.lerEntrada(mensagem, titulo);
				if (nome.isEmpty() || isNomeComNumeros(nome))
					Visao.mensagemErro("Erro, o nome nao pode ser vazio ou possuir digitos!", "Atencao");
			} catch (NullPointerException e) {
				Visao.mensagemErro("Valor incoerente! Tente novamente", "Erro");
			}
		} while (nome == null || nome.isEmpty() || isNomeComNumeros(nome));
		return nome;
	}

	public static float validaPreco(String mensagem) {
		final float MIN = 0f;
		float preco = MIN - 1;

		try {
			preco = Float.parseFloat(Leitura.lerEntrada(mensagem, "Cadastro"));
			if (preco < MIN) {
				Visao.mensagemAtencao("Erro, o valor deve ser ao menos " + MIN + " (doado).", "Atencao");
				preco = validaPreco(mensagem);
			}
		} catch (NumberFormatException e) {
			Visao.mensagemErro("Erro, a entrada deve ser numerica!", "Erro");
			preco = validaPreco(mensagem);
		} catch (NullPointerException e) {
			Visao.mensagemErro("Pre�o incoerente! Tente novamente: ", "Erro");
			preco = validaPreco(mensagem);
		}
		return preco;
	}

	public static int validaAno(String mensagem, final int ANOMINIMO, final int ATUAL) {
		int ano = ANOMINIMO - 1;

		try {
			ano = Integer.parseInt(Leitura.lerEntrada(mensagem, "Cadastro"));
			if (ano < ANOMINIMO || ano > ATUAL) {
				Visao.mensagemAtencao(
						"Erro, o valor deve estar entre " + ANOMINIMO + " e " + ATUAL + ". Tente novamente: ",
						"Atencao");
				ano = validaAno(mensagem, ANOMINIMO, ATUAL);
			}
		} catch (NumberFormatException e) {
			Visao.mensagemErro("Erro, a entrada deve ser numerica!", "Erro");
			ano = validaAno(mensagem, ANOMINIMO, ATUAL);
		} catch (NullPointerException e) {
			Visao.mensagemErro("Ano incoerente! Tente novamente: ", "Erro");
			ano = validaAno(mensagem, ANOMINIMO, ATUAL);
		}
		return ano;
	}

	public static int validaAnoMinimo(int idPintor, Galeria galeria) {
		for (Pintor pintor : galeria.getListaPintores()) {
			if (idPintor == pintor.getCodigoPessoal()) {
				return pintor.getAnoNascimento();
			}
		}
		return 1000;
	}

	public static Integer validaId(String mensagem) {
		int id = 0;

		do {
			try {
				id = Integer.parseInt(Leitura.lerEntrada(mensagem, "Cadastro"));
				if (id <= 0) {
					Visao.mensagemErro("O codigo chave deve ser maior que zero! Tente novamente.", "Atencao");
				}
			} catch (NumberFormatException e) {
				Visao.mensagemErro("Valor incoerente! Tente novamente.", "Erro");
			} catch (NullPointerException e) {
				Visao.mensagemErro("Valor incoerente! Tente novamente: ", "Erro");
			}
		} while (id <= 0);
		return id;
	}

	public static int validaCodigoPessoal(Galeria galeria, String mensagem) {
		int codigoPessoal = validaId(mensagem);
		if (isCodigoPessoalRepetido(galeria, codigoPessoal)) {
			Visao.mensagemAtencao("Erro, o valor do codigo deve ser unico e maior que zero!", "Atencao");
			codigoPessoal = validaCodigoPessoal(galeria, mensagem);
		}
		return codigoPessoal;
	}

	public static int validaCodigoPintor(Galeria galeria, String mensagem, final int ANOMINIMO, final int ATUAL) {
		int idPintor = validaId(mensagem);
		if (!isCodigoPessoalRepetido(galeria, idPintor)) {
			Visao.mensagemErro("Esse codigo chave nao existe! Tente novamente", "Atencao");
			String[] opcao = { "Listar Pintores", "Registrar novo Pintor" };
			switch (Visao.mostraMenu(opcao)) {
			case 0:
				Visao.mostraPintores(galeria);
				break;
			case 1:
				Principal.registraPintor(galeria, ANOMINIMO, ATUAL);
			}
			idPintor = validaCodigoPintor(galeria, mensagem, ANOMINIMO, ATUAL);
		}
		return idPintor;
	}

	public static int validaCodigoQuadro(Galeria galeria, String mensagem) {
		int codigoQuadro = validaId(mensagem);
		if (isCodigoQuadroRepetido(galeria, codigoQuadro)) {
			Visao.mensagemAtencao("Erro, o valor do codigo deve ser ao menos 1 e ser unico.", "Atencao");
			codigoQuadro = validaCodigoQuadro(galeria, mensagem);
		}
		return codigoQuadro;
	}

	private static boolean isCodigoQuadroRepetido(Galeria galeria, int codigoQuadro) {
		for (Quadro quadro : galeria.getListaQuadros()) {
			if (quadro.getCodigoIdentificacao().equals(codigoQuadro)) {
				return true;
			}
		}
		return false;
	}

	private static boolean isCodigoPessoalRepetido(Galeria galeria, int codigoPessoal) {
		for (Pintor pintor : galeria.getListaPintores()) {
			if (pintor.getCodigoPessoal().equals(codigoPessoal)) {
				return true;
			}
		}
		return false;
	}

	private static boolean isNomeComNumeros(String nome) {
		for (char c : nome.toCharArray()) {
			if (Character.isDigit(c)) {
				return true;
			}
		}
		return false;
	}
}
