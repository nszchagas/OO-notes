package saida;

import java.text.DecimalFormat;
import javax.swing.JOptionPane;
import dados.*;

public class Visao {

	public static void mensagemErro(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.ERROR_MESSAGE);
	}

	public static void mensagemAtencao(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.WARNING_MESSAGE);
	}

	public static int mostraMenu(String[] escolha) {
		return JOptionPane.showOptionDialog(null, "Clique na opcao desejada", "Menu", 0,
				JOptionPane.INFORMATION_MESSAGE, null, escolha, escolha[0]);
	}

	public static void mostraQuadros(Galeria galeria) {
		if (galeria.getListaQuadros().size() == 0)
			mensagemAtencao("Nenhuma obra cadastrada.", "Atencao");
		else {
			int indice = 1;
			limpaTela(30);
			System.out.println("Os quadros cadastrados s�o:");
			System.out.format("%-8s%-20s%-20s%-20s%-20s\n", "#", "ID QUADRO", "ID PINTOR", "PRECO", "ANO AQUISICAO");
			System.out.println(
					"===========================================================================================");
			for (Quadro quadro : galeria.getListaQuadros())
				System.out.println(new DecimalFormat("00").format(indice++) + quadro);
		}
	}

	public static void mostraPintores(Galeria galeria) {
		int indice = 1;
		limpaTela(30);
		String formato = "%-8s%-30s%-20s%-20s\n";
		System.out.println("Os pintores cadastrados s�o:");
		System.out.format(formato, "#", "NOME", "ANO DE NASCIMENTO", "ID PINTOR");
		System.out.println("======================================================================");

		for (Pintor pintor : galeria.getListaPintores())
			System.out.println(new DecimalFormat("00").format(indice++) + pintor);
	}

	public static void mostraQuadrosNome(Galeria galeria, String nome) {
		int indice = 1;
		int controle = 0;
		float total = 0f;

		if (galeria.getListaQuadros().size() == 0)
			mensagemAtencao("Nenhuma obra cadastrada.", "Atencao");
		else {
			limpaTela(30);
			for (Pintor pintor : galeria.getListaPintores()) {
				if (pintor.getNome().toUpperCase().contains(nome.toUpperCase())) {
					if (controle == 0) {
						System.out.println("Obra(s) do(s) pintor(es) com [" + nome + "] em seu nome: ");
						System.out.format("%-8s%-20s%-20s%-20s%-20s\n", "#", "ID QUADRO", "ID PINTOR", "PRECO",
								"ANO AQUISICAO");
						System.out.println(
								"=======================================================================================");
						controle = 1;
					}
					for (Quadro quadro : galeria.getListaQuadros()) {
						if (pintor.getCodigoPessoal() == quadro.getCodigoIdentificacaoPintor()) {
							System.out.println(new DecimalFormat("00").format(indice++) + quadro);
							total += quadro.getPreco();
						}
					}
				}
			}
			if (controle != 0)
				System.out.println("\nSoma total dos valores dos quadros do(s) pintor(es) que tem [" + nome
						+ "] em seu nome:\tR$ " + new DecimalFormat("0.00").format(total));
			else
				mensagemAtencao("Nao foi encontrado nenhum pintor com esse nome!", "Atencao");
		}
	}

	public static void limpaTela(int qtd) {
		for (int i = 0; i < qtd; i++)
			System.out.println();
	}
}
