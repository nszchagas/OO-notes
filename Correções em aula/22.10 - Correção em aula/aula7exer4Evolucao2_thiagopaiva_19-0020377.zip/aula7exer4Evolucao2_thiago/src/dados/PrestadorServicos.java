package dados;

public class PrestadorServicos extends Funcionario {
	public Float horasTrabalhadas;

	public PrestadorServicos(String nome, String dataNascimento, String cpf, Float horasTrabalhadas) {
		super(nome, dataNascimento, cpf);
		setHorasTrabalhadas(horasTrabalhadas);
	}

	@Override
	public float calculaSalario() {
		return 2 * horasTrabalhadas + super.getPiso();
	}

	public void setHorasTrabalhadas(Float horasTrabalhadas) {
		this.horasTrabalhadas = horasTrabalhadas;
	}

	public Float getHorasTrabalhadas() {
		return horasTrabalhadas;
	}
}
