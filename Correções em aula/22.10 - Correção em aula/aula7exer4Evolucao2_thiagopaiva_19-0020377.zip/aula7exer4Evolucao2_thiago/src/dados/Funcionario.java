package dados;

public class Funcionario extends Pessoa{

	public Funcionario(String nome, String dataNascimento, String cpf) {
		super(nome, dataNascimento, cpf);
	}
	
	public final float getPiso() {
		return 232.0f;
	}

	public float calculaSalario() {
		return getPiso() * 1.1F;
	}

}
