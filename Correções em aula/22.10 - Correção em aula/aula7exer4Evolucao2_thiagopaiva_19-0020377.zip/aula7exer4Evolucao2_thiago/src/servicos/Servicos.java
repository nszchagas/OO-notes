package servicos;

import dados.Empresa;
import dados.Funcionario;
import dados.Gerente;
import dados.PrestadorServicos;
import validacao.Validacao;

public class Servicos {

	public static void registraFuncionarioRegular(Empresa empresa) {
		Funcionario funcionario = new Funcionario(Validacao.validaNome(), Validacao.validaDataNascimento(),
				Validacao.validaCpf(empresa));
		empresa.setFuncionarios(funcionario);
	}

	public static void registraPrestadorServicos(Empresa empresa) {
		PrestadorServicos prestadorServicos = new PrestadorServicos(Validacao.validaNome(),
				Validacao.validaDataNascimento(), Validacao.validaCpf(empresa), Validacao.validaHorasTrabalhadas());
		empresa.setFuncionarios(prestadorServicos);
	}

	public static void registraGerente(Empresa empresa) {
		Gerente gerente = new Gerente(Validacao.validaNome(),
				Validacao.validaDataNascimento(),
				Validacao.validaCpf(empresa), Validacao.validaQuantidadeProjetos());
		empresa.setFuncionarios(gerente);
	}

}
