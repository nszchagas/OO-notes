package principal;

import dados.*;
import saida.Visao;
import validacao.Validacao;

public class Principal {

	public static void main(String[] args) {

		Turma turma = new Turma();

		do {
			Aluno aluno = new Aluno(Validacao.validaNome(), Validacao.validaMatricula(turma), Validacao.validaMedia());
			turma.setTurma(aluno);
		} while (Validacao.isContinuaCadastro());

		Visao.mostraRelatorio(turma);

	}

}
