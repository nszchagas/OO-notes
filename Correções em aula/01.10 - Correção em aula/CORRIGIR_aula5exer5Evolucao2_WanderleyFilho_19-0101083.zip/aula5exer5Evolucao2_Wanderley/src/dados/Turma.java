package dados;

import java.util.ArrayList;

public class Turma {

	private ArrayList<Aluno> turma;

	public Turma() {
		turma = new ArrayList<Aluno>();
	}

	public Aluno getAluno(int i) {
		return turma.get(i);
	}

	public ArrayList<Aluno> getTurma() {
		return this.turma;
	}

	public void setTurma(Aluno aluno) {
		this.turma.add(aluno);
	}

}
