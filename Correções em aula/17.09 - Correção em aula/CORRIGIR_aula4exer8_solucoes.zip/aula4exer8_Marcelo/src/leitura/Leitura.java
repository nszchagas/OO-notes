package leitura;

import java.util.Scanner;

public class Leitura {
	public static int lerInt(){
		Scanner ler = new Scanner(System.in);
		return ler.nextInt();
	}
	public static short lerShort(){
		Scanner ler = new Scanner(System.in);
		return ler.nextShort();
	}
}
